# UninaTaskBoard

Applicazione desktop Java Swing per organizzare progetti collaborativi e attività universitarie. Il progetto comprende gestione di progetti, task, partecipanti, inviti, commenti, revisioni e report.

## Requisiti

- Java 21
- PostgreSQL
- Eclipse IDE oppure un ambiente Java compatibile

Le librerie JDBC PostgreSQL e JFreeChart sono incluse nella cartella `lib`.

## Apertura in Eclipse

Importare la cartella del progetto con **File → Import → Existing Projects into Workspace** e selezionare la cartella `UninaTaskBoard`. La classe di avvio è `UninaTaskBoard_Launcher.MainUTB`.

## Configurazione del database

La connessione usa il database PostgreSQL `UninaTaskBoard` sull'indirizzo locale configurato nel sorgente e l'utente `postgres`. La password viene letta dalla variabile d'ambiente `DB_PASSWORD` e non è salvata nel repository.

In Eclipse, aprire **Run → Run Configurations… → MainUTB → Environment**, aggiungere `DB_PASSWORD` con la password del proprio database e salvare la configurazione. Il database deve essere predisposto localmente con lo schema richiesto dall'applicazione; gli script incrementali disponibili si trovano in `sql/migrations` e vanno applicati solo agli schemi compatibili.

## Struttura

- `src/UninaTaskBoard_GUI`: interfaccia Swing
- `src/UninaTaskBoard_DAO`: accesso ai dati
- `src/UninaTaskBoard_Model`: modelli del dominio
- `src/UninaTaskBoard_DB`: connessione al database
- `src/assets`: logo e immagini dell'applicazione
- `docs`: documentazione e diagramma EBC
- `sql/migrations`: migrazioni dello schema
