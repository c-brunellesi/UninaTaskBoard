package UninaTaskBoard_Model;

import java.util.Date;

public class Commento {
    private int idCommento;
    private String testo;
    private Date dataOra;
    private String matricolaAutore;
    private int idAttivita;

    public Commento(int idCommento, String testo, Date dataOra, String matricolaAutore, int idAttivita) {
        this.idCommento = idCommento;
        this.testo = testo;
        this.dataOra = dataOra;
        this.matricolaAutore = matricolaAutore;
        this.idAttivita = idAttivita;
    }

    public int getIdCommento() { return idCommento; }
    public void setIdCommento(int idCommento) { this.idCommento = idCommento; }

    public String getTesto() { return testo; }
    public void setTesto(String testo) { this.testo = testo; }

    public Date getDataOra() { return dataOra; }
    public void setDataOra(Date dataOra) { this.dataOra = dataOra; }

    public String getMatricolaAutore() { return matricolaAutore; }
    public void setMatricolaAutore(String matricolaAutore) { this.matricolaAutore = matricolaAutore; }

    public int getIdAttivita() { return idAttivita; }
    public void setIdAttivita(int idAttivita) { this.idAttivita = idAttivita; }
}