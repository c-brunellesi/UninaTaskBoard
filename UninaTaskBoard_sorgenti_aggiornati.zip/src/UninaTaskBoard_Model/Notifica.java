package UninaTaskBoard_Model;

import java.util.Date;

public class Notifica {
    private int idNotifica;
    private String messaggio;
    private Date dataOra;
    private boolean letta;
    private String matricolaDestinatario;

    public Notifica(int idNotifica, String messaggio, Date dataOra, boolean letta, String matricolaDestinatario) {
        this.idNotifica = idNotifica;
        this.messaggio = messaggio;
        this.dataOra = dataOra;
        this.letta = letta;
        this.matricolaDestinatario = matricolaDestinatario;
    }

    public int getIdNotifica() { return idNotifica; }
    public void setIdNotifica(int idNotifica) { this.idNotifica = idNotifica; }

    public String getMessaggio() { return messaggio; }
    public void setMessaggio(String messaggio) { this.messaggio = messaggio; }

    public Date getDataOra() { return dataOra; }
    public void setDataOra(Date dataOra) { this.dataOra = dataOra; }

    public boolean isLetta() { return letta; }
    public void setLetta(boolean letta) { this.letta = letta; }

    public String getMatricolaDestinatario() { return matricolaDestinatario; }
    public void setMatricolaDestinatario(String matricolaDestinatario) { this.matricolaDestinatario = matricolaDestinatario; }
}