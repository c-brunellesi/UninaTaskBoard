package UninaTaskBoard_Model;

public class Invito {
    private int idInvito;
    private String matricolaInvitante;
    private String matricolaDestinatario;
    private int idProg;
    private String stato;
    private String ruoloProposto;

    public Invito(int idInvito, String matricolaInvitante, String matricolaDestinatario, int idProg, String stato, String ruoloProposto) {
        this.idInvito = idInvito;
        this.matricolaInvitante = matricolaInvitante;
        this.matricolaDestinatario = matricolaDestinatario;
        this.idProg = idProg;
        this.stato = stato;
        this.ruoloProposto = ruoloProposto;
    }

    public int getIdInvito() { return idInvito; }
    public void setIdInvito(int idInvito) { this.idInvito = idInvito; }

    public String getMatricolaInvitante() { return matricolaInvitante; }
    public void setMatricolaInvitante(String matricolaInvitante) { this.matricolaInvitante = matricolaInvitante; }

    public String getMatricolaDestinatario() { return matricolaDestinatario; }
    public void setMatricolaDestinatario(String matricolaDestinatario) { this.matricolaDestinatario = matricolaDestinatario; }

    public int getIdProg() { return idProg; }
    public void setIdProg(int idProg) { this.idProg = idProg; }

    public String getStato() { return stato; }
    public void setStato(String stato) { this.stato = stato; }

    public String getRuoloProposto() { return ruoloProposto; }
    public void setRuoloProposto(String ruoloProposto) { this.ruoloProposto = ruoloProposto; }
}