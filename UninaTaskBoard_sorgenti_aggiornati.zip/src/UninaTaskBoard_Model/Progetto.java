package UninaTaskBoard_Model;

import java.util.Date;

public class Progetto {
    private int idProg;
    private String nome;
    private Date dataInizio;
    private Date dataScadenza;
    private String tipoProgetto;
    private String materia;
    private String linguaggio;
    private String matricolaDirigente;

    public Progetto(int idProg, String nome, Date dataInizio, Date dataScadenza, String tipoProgetto, String materia, String linguaggio, String matricolaDirigente) {
        this.idProg = idProg;
        this.nome = nome;
        this.dataInizio = dataInizio;
        this.dataScadenza = dataScadenza;
        this.tipoProgetto = tipoProgetto;
        this.materia = materia;
        this.linguaggio = linguaggio;
        this.matricolaDirigente = matricolaDirigente;
    }

    public int getIdProg() { return idProg; }
    public void setIdProg(int idProg) { this.idProg = idProg; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public Date getDataInizio() { return dataInizio; }
    public void setDataInizio(Date dataInizio) { this.dataInizio = dataInizio; }

    public Date getDataScadenza() { return dataScadenza; }
    public void setDataScadenza(Date dataScadenza) { this.dataScadenza = dataScadenza; }

    public String getTipoProgetto() { return tipoProgetto; }
    public void setTipoProgetto(String tipoProgetto) { this.tipoProgetto = tipoProgetto; }

    public String getMateria() { return materia; }
    public void setMateria(String materia) { this.materia = materia; }

    public String getLinguaggio() { return linguaggio; }
    public void setLinguaggio(String linguaggio) { this.linguaggio = linguaggio; }

    public String getMatricolaDirigente() { return matricolaDirigente; }
    public void setMatricolaDirigente(String matricolaDirigente) { this.matricolaDirigente = matricolaDirigente; }

    public String getMatricolaCreatore() { return matricolaDirigente; }
}