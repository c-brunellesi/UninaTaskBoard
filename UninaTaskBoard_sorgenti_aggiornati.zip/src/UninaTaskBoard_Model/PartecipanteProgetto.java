package UninaTaskBoard_Model;

import java.util.Date;

public class PartecipanteProgetto {
    private final String nome;
    private final String cognome;
    private final String matricola;
    private final Date dataPartecipazione;
    private final boolean dirigente;

    public PartecipanteProgetto(String nome, String cognome, String matricola, Date dataPartecipazione, boolean dirigente) {
        this.nome = nome;
        this.cognome = cognome;
        this.matricola = matricola;
        this.dataPartecipazione = dataPartecipazione;
        this.dirigente = dirigente;
    }

    public String getNome() { return nome; }
    public String getCognome() { return cognome; }
    public String getMatricola() { return matricola; }
    public Date getDataPartecipazione() { return dataPartecipazione; }
    public boolean isDirigente() { return dirigente; }
}
