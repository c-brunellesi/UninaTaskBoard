package UninaTaskBoard_Model;

import java.util.Date;

public class Revisione {
    private int idRevisione;
    private Date dataOra;
    private String esito;
    private String note;
    private String matricolaRevisore;
    private int idAttivita;
    private String nomeAutore;
    private String codiceSorgente;
    private String nomeAttivita;

    public Revisione(int idRevisione, Date dataOra, String esito, String note, String matricolaRevisore, int idAttivita) {
        this.idRevisione = idRevisione;
        this.dataOra = dataOra;
        this.esito = esito;
        this.note = note;
        this.matricolaRevisore = matricolaRevisore;
        this.idAttivita = idAttivita;
    }

    public int getIdRevisione() { return idRevisione; }
    public void setIdRevisione(int idRevisione) { this.idRevisione = idRevisione; }

    public Date getDataOra() { return dataOra; }
    public void setDataOra(Date dataOra) { this.dataOra = dataOra; }

    public String getEsito() { return esito; }
    public void setEsito(String esito) { this.esito = esito; }

    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }

    public String getMatricolaRevisore() { return matricolaRevisore; }
    public void setMatricolaRevisore(String matricolaRevisore) { this.matricolaRevisore = matricolaRevisore; }

    public int getIdAttivita() { return idAttivita; }
    public void setIdAttivita(int idAttivita) { this.idAttivita = idAttivita; }

    public String getNomeAutore() { return nomeAutore; }
    public void setNomeAutore(String nomeAutore) { this.nomeAutore = nomeAutore; }

    public String getCodiceSorgente() { return codiceSorgente; }
    public void setCodiceSorgente(String codiceSorgente) { this.codiceSorgente = codiceSorgente; }

    public String getNomeAttivita() { return nomeAttivita; }
    public void setNomeAttivita(String nomeAttivita) { this.nomeAttivita = nomeAttivita; }
}
