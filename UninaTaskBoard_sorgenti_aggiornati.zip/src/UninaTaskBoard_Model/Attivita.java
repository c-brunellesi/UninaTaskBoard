package UninaTaskBoard_Model;

import java.util.Date;

public class Attivita {
    private int idAttivita;
    private String titolo;
    private String descrizione;
    private Date dataInizio;
    private Date dataScadenza;
    private String stato;
    private String tipoAttivita;
    private String codiceModulo;
    private String urlDocumento;
    private int idProg;

    public Attivita(int idAttivita, String titolo, String descrizione, Date dataInizio, Date dataScadenza, String stato, String tipoAttivita, String codiceModulo, String urlDocumento, int idProg) {
        this.idAttivita = idAttivita;
        this.titolo = titolo;
        this.descrizione = descrizione;
        this.dataInizio = dataInizio;
        this.dataScadenza = dataScadenza;
        this.stato = stato;
        this.tipoAttivita = tipoAttivita;
        this.codiceModulo = codiceModulo;
        this.urlDocumento = urlDocumento;
        this.idProg = idProg;
    }

    public int getIdAttivita() { return idAttivita; }
    public void setIdAttivita(int idAttivita) { this.idAttivita = idAttivita; }

    public String getTitolo() { return titolo; }
    public void setTitolo(String titolo) { this.titolo = titolo; }

    public String getDescrizione() { return descrizione; }
    public void setDescrizione(String descrizione) { this.descrizione = descrizione; }

    public Date getDataInizio() { return dataInizio; }
    public void setDataInizio(Date dataInizio) { this.dataInizio = dataInizio; }

    public Date getDataScadenza() { return dataScadenza; }
    public void setDataScadenza(Date dataScadenza) { this.dataScadenza = dataScadenza; }

    public String getStato() { return stato; }
    public void setStato(String stato) { this.stato = stato; }

    public String getTipoAttivita() { return tipoAttivita; }
    public void setTipoAttivita(String tipoAttivita) { this.tipoAttivita = tipoAttivita; }

    public String getCodiceModulo() { return codiceModulo; }
    public void setCodiceModulo(String codiceModulo) { this.codiceModulo = codiceModulo; }

    public String getUrlDocumento() { return urlDocumento; }
    public void setUrlDocumento(String urlDocumento) { this.urlDocumento = urlDocumento; }

    public int getIdProg() { return idProg; }
    public void setIdProg(int idProg) { this.idProg = idProg; }
}