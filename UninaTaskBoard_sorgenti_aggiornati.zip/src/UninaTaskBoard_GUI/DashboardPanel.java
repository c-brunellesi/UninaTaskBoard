package UninaTaskBoard_GUI;

import UninaTaskBoard_DAO.AttivitaDAO;
import UninaTaskBoard_DAO.ProgettoDAO;
import UninaTaskBoard_DAO.NotificaDAO;
import UninaTaskBoard_Model.Attivita;
import UninaTaskBoard_Model.Progetto;
import UninaTaskBoard_Model.Utente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class DashboardPanel extends JPanel {

    private Utente utente;
    private MainFrame mainFrame;
    private ProgettoDAO progettoDAO;
    private AttivitaDAO attivitaDAO;
    private NotificaDAO notificaDAO;

    private JLabel lblProgettiTotali;
    private JLabel lblTaskAperti;
    private JLabel lblNotificheCount;

    private JPanel pnlListaProgetti;
    private JPanel pnlListaAttivita;

    private final Color COLOR_PRIMARY = new Color(0, 28, 99);
    private final Color COLOR_BG = new Color(245, 247, 250);

    public DashboardPanel(Utente utente, MainFrame mainFrame) {
        this.utente = utente;
        this.mainFrame = mainFrame;
        this.progettoDAO = new ProgettoDAO();
        this.attivitaDAO = new AttivitaDAO();
        this.notificaDAO = new NotificaDAO();

        setLayout(new BorderLayout(20, 20));
        setBackground(COLOR_BG);
        setBorder(new EmptyBorder(25, 25, 25, 25));

        JPanel pnlHeader = new JPanel(new BorderLayout());
        pnlHeader.setOpaque(false);

        JLabel lblTitle = new JLabel("DASHBOARD");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(COLOR_PRIMARY);

        JLabel lblSub = new JLabel("Panoramica generale delle attività e progetti");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSub.setForeground(new Color(100, 100, 100));

        JPanel pnlTitleGroup = new JPanel(new GridLayout(2, 1, 0, 4));
        pnlTitleGroup.setOpaque(false);
        pnlTitleGroup.add(lblTitle);
        pnlTitleGroup.add(lblSub);

        pnlHeader.add(pnlTitleGroup, BorderLayout.WEST);

        JPanel pnlStats = new JPanel(new GridLayout(1, 3, 15, 0));
        pnlStats.setOpaque(false);

        lblProgettiTotali = new JLabel("0", SwingConstants.CENTER);
        lblTaskAperti = new JLabel("0", SwingConstants.CENTER);
        lblNotificheCount = new JLabel("0", SwingConstants.CENTER);

        pnlStats.add(creaStatCard("Progetti Attivi", lblProgettiTotali));
        pnlStats.add(creaStatCard("Task Pendenti", lblTaskAperti));
        pnlStats.add(creaStatCard("Notifiche Non Lette", lblNotificheCount));

        JPanel pnlTop = new JPanel(new BorderLayout(0, 15));
        pnlTop.setOpaque(false);
        pnlTop.add(pnlHeader, BorderLayout.NORTH);
        pnlTop.add(pnlStats, BorderLayout.CENTER);

        JPanel pnlContent = new JPanel(new GridLayout(1, 2, 20, 0));
        pnlContent.setOpaque(false);

        pnlListaProgetti = new JPanel();
        pnlListaProgetti.setLayout(new BoxLayout(pnlListaProgetti, BoxLayout.Y_AXIS));
        pnlListaProgetti.setOpaque(false);

        pnlListaAttivita = new JPanel();
        pnlListaAttivita.setLayout(new BoxLayout(pnlListaAttivita, BoxLayout.Y_AXIS));
        pnlListaAttivita.setOpaque(false);

        pnlContent.add(creaSectionCard("Progetti Recenti", pnlListaProgetti));
        pnlContent.add(creaSectionCard("Prossime Scadenze / Task", pnlListaAttivita));

        add(pnlTop, BorderLayout.NORTH);
        add(pnlContent, BorderLayout.CENTER);

        caricaDati();
    }

    private JPanel creaStatCard(String titolo, JLabel lblValore) {
        LoginFrame.RoundedPanel card = new LoginFrame.RoundedPanel(15, Color.WHITE);
        card.setLayout(new BorderLayout(5, 5));
        card.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblT = new JLabel(titolo, SwingConstants.CENTER);
        lblT.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblT.setForeground(new Color(120, 120, 120));

        lblValore.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblValore.setForeground(COLOR_PRIMARY);

        card.add(lblT, BorderLayout.NORTH);
        card.add(lblValore, BorderLayout.CENTER);
        return card;
    }

    private JPanel creaSectionCard(String titolo, JPanel pnlInner) {
        LoginFrame.RoundedPanel card = new LoginFrame.RoundedPanel(15, Color.WHITE);
        card.setLayout(new BorderLayout(10, 10));
        card.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblT = new JLabel(titolo);
        lblT.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblT.setForeground(COLOR_PRIMARY);

        JScrollPane scroll = new JScrollPane(pnlInner);
        scroll.setBorder(null);
        scroll.getViewport().setOpaque(false);
        scroll.setOpaque(false);

        card.add(lblT, BorderLayout.NORTH);
        card.add(scroll, BorderLayout.CENTER);
        return card;
    }

    public void caricaDati() {
        List<Progetto> progetti = progettoDAO.getProgettiPerUtente(utente.getMatricola());
        List<Attivita> attivita = attivitaDAO.getAttivitaPerUtente(utente.getMatricola());

        lblProgettiTotali.setText(String.valueOf(progetti.size()));
        lblTaskAperti.setText(String.valueOf(attivita.stream().filter(a -> !"Completata".equalsIgnoreCase(a.getStato())).count()));
        lblNotificheCount.setText(String.valueOf(notificaDAO.getConteggioNotificheNonLette(utente.getMatricola())));

        pnlListaProgetti.removeAll();
        for (Progetto p : progetti) {
            String dettaglio = "Tipo: " + p.getTipoProgetto();
            if ("Esame".equals(p.getTipoProgetto()) && p.getMateria() != null && !p.getMateria().isBlank()) {
                dettaglio += " · Materia: " + p.getMateria();
            } else if ("Sviluppo".equals(p.getTipoProgetto()) && p.getLinguaggio() != null && !p.getLinguaggio().isBlank()) {
                dettaglio += " · Linguaggio: " + p.getLinguaggio();
            }
            pnlListaProgetti.add(creaItemCard(p.getNome(), dettaglio));
            pnlListaProgetti.add(Box.createRigidArea(new Dimension(0, 8)));
        }

        pnlListaAttivita.removeAll();
        for (Attivita a : attivita) {
            pnlListaAttivita.add(creaItemCard(a.getTitolo(), "Stato: " + a.getStato() + " | Scadenza: " + (a.getDataScadenza() != null ? a.getDataScadenza().toString() : "N/D")));
            pnlListaAttivita.add(Box.createRigidArea(new Dimension(0, 8)));
        }

        pnlListaProgetti.revalidate();
        pnlListaProgetti.repaint();
        pnlListaAttivita.revalidate();
        pnlListaAttivita.repaint();
    }

    private JPanel creaItemCard(String titolo, String sottotitolo) {
        LoginFrame.RoundedPanel p = new LoginFrame.RoundedPanel(10, new Color(248, 250, 253));
        p.setLayout(new BorderLayout(5, 3));
        p.setBorder(new EmptyBorder(8, 10, 8, 10));

        JLabel l1 = new JLabel(titolo);
        l1.setFont(new Font("Segoe UI", Font.BOLD, 13));
        l1.setForeground(COLOR_PRIMARY);

        JLabel l2 = new JLabel(sottotitolo);
        l2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        l2.setForeground(new Color(100, 100, 100));

        p.add(l1, BorderLayout.NORTH);
        p.add(l2, BorderLayout.SOUTH);
        return p;
    }
}
