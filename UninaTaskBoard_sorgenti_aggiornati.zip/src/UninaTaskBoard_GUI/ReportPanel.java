package UninaTaskBoard_GUI;

import UninaTaskBoard_DAO.ProgettoDAO;
import UninaTaskBoard_DAO.ReportDAO;
import UninaTaskBoard_Model.Progetto;
import UninaTaskBoard_Model.Utente;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.Map;

public class ReportPanel extends JPanel {
    private final Utente utente;
    private final ProgettoDAO progettoDAO = new ProgettoDAO();
    private final ReportDAO reportDAO = new ReportDAO();
    private final Color primary = new Color(0, 28, 99);
    private JComboBox<Progetto> progetti;
    private JPanel metriche;
    private JPanel grafici;

    public ReportPanel(Utente utente) {
        this.utente = utente;
        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(245, 247, 250));
        setBorder(new EmptyBorder(25, 25, 25, 25));
        JPanel intestazione = new JPanel(new BorderLayout(12, 0));
        intestazione.setOpaque(false);
        JLabel titolo = new JLabel("REPORT DEI PROGETTI");
        titolo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titolo.setForeground(primary);
        progetti = new JComboBox<>();
        progetti.setPreferredSize(new Dimension(260, 36));
        progetti.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean selected, boolean focus) {
                super.getListCellRendererComponent(list, value, index, selected, focus);
                if (value instanceof Progetto) setText(((Progetto) value).getNome());
                return this;
            }
        });
        progetti.addActionListener(e -> aggiornaReport());
        intestazione.add(titolo, BorderLayout.WEST);
        intestazione.add(progetti, BorderLayout.EAST);
        add(intestazione, BorderLayout.NORTH);
        JPanel centro = new JPanel(new BorderLayout(14, 14));
        centro.setOpaque(false);
        metriche = new JPanel(new GridLayout(1, 6, 10, 0));
        metriche.setOpaque(false);
        grafici = new JPanel(new GridLayout(1, 2, 14, 0));
        grafici.setOpaque(false);
        centro.add(metriche, BorderLayout.NORTH);
        centro.add(grafici, BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);
        caricaProgetti();
    }

    private void caricaProgetti() {
        List<Progetto> elenco = progettoDAO.getProgettiPerUtente(utente.getMatricola());
        for (Progetto progetto : elenco) progetti.addItem(progetto);
        if (elenco.isEmpty()) mostraVuoto();
    }

    private void aggiornaReport() {
        Progetto progetto = (Progetto) progetti.getSelectedItem();
        if (progetto == null) {
            mostraVuoto();
            return;
        }
        int[] dati = reportDAO.getConteggiAttivita(progetto.getIdProg());
        int sviluppo = reportDAO.getNumeroAttivitaSviluppo(progetto.getIdProg());
        double mediaRevisioni = reportDAO.getMediaRevisioniPerFileCodice(progetto.getIdProg());
        metriche.removeAll();
        metriche.add(creaMetrica("Attività totali", dati[0]));
        metriche.add(creaMetrica("Iniziate", dati[1]));
        metriche.add(creaMetrica("In corso", dati[2]));
        metriche.add(creaMetrica("Finite", dati[3]));
        metriche.add(creaMetrica("Sviluppo", sviluppo));
        metriche.add(creaMetrica("Media revisioni/file", mediaRevisioni));
        DefaultPieDataset<String> stati = new DefaultPieDataset<>();
        stati.setValue("Iniziato", dati[1]);
        stati.setValue("In Corso", dati[2]);
        stati.setValue("Finito", dati[3]);
        JFreeChart torta = ChartFactory.createPieChart("Stato delle attività", stati, true, true, false);
        torta.setBackgroundPaint(Color.WHITE);
        torta.getTitle().setFont(new Font("Segoe UI", Font.BOLD, 15));
        if (torta.getLegend() != null) torta.getLegend().setItemFont(new Font("Segoe UI", Font.PLAIN, 11));
        PiePlot piePlot = (PiePlot) torta.getPlot();
        piePlot.setBackgroundPaint(Color.WHITE);
        piePlot.setOutlineVisible(false);
        piePlot.setSectionPaint("Iniziato", new Color(213, 76, 76));
        piePlot.setSectionPaint("In Corso", new Color(232, 150, 50));
        piePlot.setSectionPaint("Finito", new Color(54, 145, 92));
        DefaultCategoryDataset membri = new DefaultCategoryDataset();
        for (Map.Entry<String, Integer> entry : reportDAO.getAttivitaFinitePerMembro(progetto.getIdProg()).entrySet()) {
            membri.addValue(entry.getValue(), "Attività finite", entry.getKey());
        }
        JFreeChart barre = ChartFactory.createBarChart("Attività finite per membro", "Membro", "Attività", membri);
        barre.setBackgroundPaint(Color.WHITE);
        barre.getTitle().setFont(new Font("Segoe UI", Font.BOLD, 15));
        CategoryPlot categoryPlot = barre.getCategoryPlot();
        categoryPlot.setBackgroundPaint(new Color(248, 250, 253));
        categoryPlot.setRangeGridlinePaint(new Color(220, 227, 236));
        categoryPlot.getRenderer().setSeriesPaint(0, new Color(0, 48, 135));
        grafici.removeAll();
        grafici.add(creaPannelloGrafico(torta));
        grafici.add(creaPannelloGrafico(barre));
        metriche.revalidate();
        metriche.repaint();
        grafici.revalidate();
        grafici.repaint();
        setToolTipText("Media revisioni per file di codice: " + String.format(java.util.Locale.ITALY, "%.2f", mediaRevisioni));
    }

    private JPanel creaMetrica(String titolo, int valore) {
        return creaMetrica(titolo, String.valueOf(valore));
    }

    private JPanel creaMetrica(String titolo, double valore) {
        return creaMetrica(titolo, String.format(java.util.Locale.ITALY, "%.2f", valore));
    }

    private JPanel creaMetrica(String titolo, String valore) {
        LoginFrame.RoundedPanel pannello = new LoginFrame.RoundedPanel(14, Color.WHITE);
        pannello.setLayout(new BorderLayout(4, 4));
        pannello.setBorder(new EmptyBorder(12, 10, 12, 10));
        JLabel numero = new JLabel(valore, SwingConstants.CENTER);
        numero.setFont(new Font("Segoe UI", Font.BOLD, 24));
        numero.setForeground(primary);
        JLabel nome = new JLabel(titolo, SwingConstants.CENTER);
        nome.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        pannello.add(numero, BorderLayout.CENTER);
        pannello.add(nome, BorderLayout.SOUTH);
        return pannello;
    }

    private JPanel creaPannelloGrafico(JFreeChart chart) {
        LoginFrame.RoundedPanel pannello = new LoginFrame.RoundedPanel(14, Color.WHITE);
        pannello.setLayout(new BorderLayout());
        pannello.setBorder(new EmptyBorder(8, 8, 8, 8));
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setOpaque(false);
        chartPanel.setPreferredSize(new Dimension(450, 370));
        pannello.add(chartPanel, BorderLayout.CENTER);
        return pannello;
    }

    private void mostraVuoto() {
        metriche.removeAll();
        grafici.removeAll();
        metriche.revalidate();
        grafici.revalidate();
        metriche.repaint();
        grafici.repaint();
    }

    public void caricaReport() {
        aggiornaReport();
    }
}
