package UninaTaskBoard_GUI;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class CustomDialog extends JDialog {

    private JPanel contentPanel;
    private final Color COLOR_PRIMARY = new Color(0, 28, 99);

    public CustomDialog(Frame parent, String titolo) {
        super(parent, titolo, true);
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));

        LoginFrame.RoundedPanel mainContainer = new LoginFrame.RoundedPanel(20, Color.WHITE);
        mainContainer.setLayout(new BorderLayout());
        mainContainer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 215, 230), 2, true),
                new EmptyBorder(15, 20, 20, 20)
        ));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JLabel lblTitle = new JLabel(titolo);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitle.setForeground(COLOR_PRIMARY);

        LoginFrame.RoundedButton btnClose = new LoginFrame.RoundedButton("", 8,
                new Color(245, 247, 250), new Color(230, 238, 248), COLOR_PRIMARY);
        btnClose.setIcon(new ReturnIcon(COLOR_PRIMARY));
        btnClose.setPreferredSize(new Dimension(32, 28));
        btnClose.setToolTipText("Torna indietro");
        btnClose.getAccessibleContext().setAccessibleName("Torna indietro");
        btnClose.addActionListener(e -> dispose());

        headerPanel.add(lblTitle, BorderLayout.WEST);
        headerPanel.add(btnClose, BorderLayout.EAST);

        contentPanel = new JPanel();
        contentPanel.setOpaque(false);

        mainContainer.add(headerPanel, BorderLayout.NORTH);
        mainContainer.add(contentPanel, BorderLayout.CENTER);

        add(mainContainer);
        pack();
        setLocationRelativeTo(parent);
    }

    private static class ReturnIcon implements Icon {
        private final Color color;
        private ReturnIcon(Color color) { this.color = color; }
        public int getIconWidth() { return 18; }
        public int getIconHeight() { return 18; }
        public void paintIcon(Component component, Graphics graphics, int x, int y) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(color);
            g.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.drawLine(x + 15, y + 4, x + 15, y + 9);
            g.drawLine(x + 15, y + 9, x + 4, y + 9);
            g.drawLine(x + 4, y + 9, x + 8, y + 5);
            g.drawLine(x + 4, y + 9, x + 8, y + 13);
            g.dispose();
        }
    }

    public JPanel getContentPanel() {
        return contentPanel;
    }
}
