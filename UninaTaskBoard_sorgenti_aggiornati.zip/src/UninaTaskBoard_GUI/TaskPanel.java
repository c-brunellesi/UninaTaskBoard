package UninaTaskBoard_GUI;

import UninaTaskBoard_DAO.AttivitaDAO;
import UninaTaskBoard_DAO.RevisioneDAO;
import UninaTaskBoard_DAO.ProgettoDAO;
import UninaTaskBoard_DAO.UtenteDAO;
import UninaTaskBoard_Model.Attivita;
import UninaTaskBoard_Model.Progetto;
import UninaTaskBoard_Model.Revisione;
import UninaTaskBoard_Model.Utente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TaskPanel extends JPanel {

    private Utente utente;
    private MainFrame mainFrame;
    private AttivitaDAO attivitaDAO;
    private ProgettoDAO progettoDAO;
    private UtenteDAO utenteDAO;
    private RevisioneDAO revisioneDAO;

    private JPanel pnlListaTask;
    private JComboBox<String> cmbFiltroStato;
    private JComboBox<String> cmbFiltroTipo;
    private JComboBox<String> cmbFiltroScadenza;
    private JComboBox<Utente> cmbFiltroMembro;
    private JComboBox<Progetto> cmbFiltroProgetto;
    private Map<Integer, List<String>> assegnatariPerAttivita = new HashMap<>();

    private final Color COLOR_PRIMARY = new Color(0, 28, 99);
    private final Color COLOR_BG = new Color(245, 247, 250);

    public TaskPanel(Utente utente, MainFrame mainFrame) {
        this.utente = utente;
        this.mainFrame = mainFrame;
        this.attivitaDAO = new AttivitaDAO();
        this.progettoDAO = new ProgettoDAO();
        this.utenteDAO = new UtenteDAO();
        this.revisioneDAO = new RevisioneDAO();

        setLayout(new BorderLayout(15, 15));
        setBackground(COLOR_BG);
        setBorder(new EmptyBorder(25, 25, 25, 25));

        JPanel pnlHeader = new JPanel(new BorderLayout(0, 10));
        pnlHeader.setOpaque(false);

        JPanel barraTitolo = new JPanel(new BorderLayout());
        barraTitolo.setOpaque(false);

        JLabel lblTitle = new JLabel("TASK BOARD - I MIEI TASK");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(COLOR_PRIMARY);

        LoginFrame.RoundedButton btnCrea = new LoginFrame.RoundedButton("+ Crea Nuovo Task", 10);
        btnCrea.setPreferredSize(new Dimension(180, 36));
        btnCrea.addActionListener(e -> mostraDialogCreaTask());

        JPanel azioniTitolo = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        azioniTitolo.setOpaque(false);
        LoginFrame.RoundedButton btnRevisioni = new LoginFrame.RoundedButton("Storico revisioni", 10,
                new Color(236, 242, 249), new Color(222, 232, 244), COLOR_PRIMARY);
        btnRevisioni.setPreferredSize(new Dimension(150, 36));
        btnRevisioni.addActionListener(e -> mostraStoricoRevisioni());
        azioniTitolo.add(btnRevisioni);
        azioniTitolo.add(btnCrea);

        barraTitolo.add(lblTitle, BorderLayout.WEST);
        barraTitolo.add(azioniTitolo, BorderLayout.EAST);
        pnlHeader.add(barraTitolo, BorderLayout.NORTH);
        pnlHeader.add(creaFiltri(), BorderLayout.SOUTH);

        pnlListaTask = new JPanel();
        pnlListaTask.setLayout(new BoxLayout(pnlListaTask, BoxLayout.Y_AXIS));
        pnlListaTask.setOpaque(false);

        JScrollPane scroll = new JScrollPane(pnlListaTask);
        scroll.setBorder(null);
        scroll.getViewport().setOpaque(false);
        scroll.setOpaque(false);

        add(pnlHeader, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        caricaFiltroMembri();
        caricaTask();
    }

    private JPanel creaFiltri() {
        JPanel filtri = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filtri.setOpaque(false);
        cmbFiltroProgetto = new JComboBox<>();
        cmbFiltroProgetto.addItem(null);
        for (Progetto progetto : progettoDAO.getProgettiPerUtente(utente.getMatricola())) cmbFiltroProgetto.addItem(progetto);
        cmbFiltroProgetto.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean selected, boolean focus) {
                super.getListCellRendererComponent(list, value, index, selected, focus);
                setText(value instanceof Progetto ? ((Progetto) value).getNome() : "Tutti i progetti");
                return this;
            }
        });
        cmbFiltroStato = new JComboBox<>(new String[]{"Tutti gli stati", "Iniziato", "In Corso", "Finito"});
        cmbFiltroTipo = new JComboBox<>(new String[]{"Tutti i tipi", "Documentazione", "Sviluppo"});
        cmbFiltroScadenza = new JComboBox<>(new String[]{"Tutte le scadenze", "Senza scadenza", "Scadute", "Entro 7 giorni"});
        cmbFiltroMembro = new JComboBox<>();
        cmbFiltroMembro.addItem(null);
        cmbFiltroMembro.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean selected, boolean focus) {
                super.getListCellRendererComponent(list, value, index, selected, focus);
                setText(value instanceof Utente ? ((Utente) value).getNome() + " " + ((Utente) value).getCognome() : "Tutti i membri");
                return this;
            }
        });
        filtri.add(etichettaFiltro("Progetto", cmbFiltroProgetto));
        filtri.add(etichettaFiltro("Stato", cmbFiltroStato));
        filtri.add(etichettaFiltro("Tipo", cmbFiltroTipo));
        filtri.add(etichettaFiltro("Scadenza", cmbFiltroScadenza));
        filtri.add(etichettaFiltro("Responsabile", cmbFiltroMembro));
        cmbFiltroProgetto.addActionListener(e -> caricaTask());
        cmbFiltroStato.addActionListener(e -> caricaTask());
        cmbFiltroTipo.addActionListener(e -> caricaTask());
        cmbFiltroScadenza.addActionListener(e -> caricaTask());
        cmbFiltroMembro.addActionListener(e -> caricaTask());
        return filtri;
    }

    private JPanel etichettaFiltro(String testo, JComponent controllo) {
        JPanel pannello = new JPanel(new BorderLayout(0, 3));
        pannello.setOpaque(false);
        JLabel label = new JLabel(testo);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        label.setForeground(COLOR_PRIMARY);
        pannello.add(label, BorderLayout.NORTH);
        pannello.add(controllo, BorderLayout.CENTER);
        return pannello;
    }

    private void caricaFiltroMembri() {
        Map<String, Utente> membri = new LinkedHashMap<>();
        for (Progetto progetto : progettoDAO.getProgettiPerUtente(utente.getMatricola())) {
            for (Utente membro : utenteDAO.getUtentiPartecipantiProgetto(progetto.getIdProg())) membri.put(membro.getMatricola(), membro);
        }
        cmbFiltroMembro.removeAllItems();
        cmbFiltroMembro.addItem(null);
        for (Utente membro : membri.values()) cmbFiltroMembro.addItem(membro);
    }

    public void caricaTask() {
        pnlListaTask.removeAll();
        List<Attivita> lista = attivitaDAO.getAttivitaPerUtente(utente.getMatricola());
        assegnatariPerAttivita = attivitaDAO.getAssegnatariPerUtente(utente.getMatricola());

        for (Attivita a : lista) {
            if (corrispondeAiFiltri(a)) {
                pnlListaTask.add(creaCardTask(a));
                pnlListaTask.add(Box.createRigidArea(new Dimension(0, 10)));
            }
        }

        pnlListaTask.revalidate();
        pnlListaTask.repaint();
    }

    public void selezionaProgetto(int idProg) {
        for (int i = 0; i < cmbFiltroProgetto.getItemCount(); i++) {
            Progetto progetto = cmbFiltroProgetto.getItemAt(i);
            if (progetto != null && progetto.getIdProg() == idProg) {
                cmbFiltroProgetto.setSelectedIndex(i);
                return;
            }
        }
    }

    private void mostraStoricoRevisioni() {
        List<Progetto> progetti = progettoDAO.getProgettiPerUtente(utente.getMatricola());
        if (progetti.isEmpty()) return;

        JComboBox<Progetto> filtroProgetto = new JComboBox<>(progetti.toArray(new Progetto[0]));
        filtroProgetto.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean selected, boolean focus) {
                super.getListCellRendererComponent(list, value, index, selected, focus);
                if (value instanceof Progetto) setText(((Progetto) value).getNome());
                return this;
            }
        });
        DefaultListModel<Revisione> modello = new DefaultListModel<>();
        JList<Revisione> elenco = new JList<>(modello);
        elenco.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        elenco.setFixedCellHeight(48);
        elenco.setCellRenderer((list, revisione, index, selected, focus) -> {
            JPanel riga = new JPanel(new BorderLayout(0, 3));
            riga.setOpaque(true);
            riga.setBackground(selected ? list.getSelectionBackground() : list.getBackground());
            riga.setBorder(new EmptyBorder(5, 8, 5, 8));
            JLabel attivita = new JLabel(revisione.getNomeAttivita());
            attivita.setFont(new Font("Segoe UI", Font.BOLD, 12));
            JLabel meta = new JLabel(revisione.getNomeAutore() + " · "
                    + new java.text.SimpleDateFormat("dd/MM/yyyy").format(revisione.getDataOra()));
            meta.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            riga.add(attivita, BorderLayout.NORTH);
            riga.add(meta, BorderLayout.CENTER);
            return riga;
        });
        JTextArea dettagli = new JTextArea();
        dettagli.setEditable(false);
        dettagli.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        elenco.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && elenco.getSelectedValue() != null) {
                dettagli.setText(testoDettaglioRevisione(elenco.getSelectedValue()));
                dettagli.setCaretPosition(0);
            }
        });
        JLabel stato = new JLabel(" ");
        stato.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        Runnable caricaRevisioni = () -> {
            modello.clear();
            Progetto progetto = (Progetto) filtroProgetto.getSelectedItem();
            if (progetto == null) return;
            for (Revisione revisione : revisioneDAO.getRevisioniPerProgetto(progetto.getIdProg())) {
                modello.addElement(revisione);
            }
            if (modello.isEmpty()) {
                dettagli.setText("");
                stato.setText("Questo progetto non contiene revisioni.");
            } else {
                stato.setText("Revisioni trovate: " + modello.size());
                elenco.setSelectedIndex(0);
            }
        };
        filtroProgetto.addActionListener(e -> caricaRevisioni.run());

        JPanel intestazione = new JPanel(new BorderLayout(8, 0));
        intestazione.setOpaque(false);
        JLabel etichetta = new JLabel("Progetto");
        etichetta.setFont(new Font("Segoe UI", Font.BOLD, 12));
        intestazione.add(etichetta, BorderLayout.WEST);
        intestazione.add(filtroProgetto, BorderLayout.CENTER);
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                new JScrollPane(elenco), new JScrollPane(dettagli));
        split.setResizeWeight(0.38);
        CustomDialog dialog = new CustomDialog((Frame) SwingUtilities.getWindowAncestor(this), "Storico revisioni");
        dialog.setPreferredSize(new Dimension(900, 640));
        JPanel content = dialog.getContentPanel();
        content.setLayout(new BorderLayout(0, 10));
        JPanel nord = new JPanel(new BorderLayout(0, 6));
        nord.setOpaque(false);
        nord.add(intestazione, BorderLayout.NORTH);
        nord.add(stato, BorderLayout.SOUTH);
        content.add(nord, BorderLayout.NORTH);
        content.add(split, BorderLayout.CENTER);
        caricaRevisioni.run();
        dialog.pack();
        dialog.setSize(900, 640);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private String testoDettaglioRevisione(Revisione revisione) {
        String data = new java.text.SimpleDateFormat("dd/MM/yyyy").format(revisione.getDataOra());
        String descrizione = revisione.getNote();
        if (descrizione != null && descrizione.equals(revisione.getCodiceSorgente())) {
            descrizione = "Non registrata per questa revisione storica.";
        }
        return "Attività: " + revisione.getNomeAttivita()
                + "\nAutore: " + revisione.getNomeAutore()
                + "\nData: " + data
                + "\n\nDescrizione dell'intervento\n" + descrizione
                + "\n\nCodice modificato\n" + (revisione.getCodiceSorgente() == null
                ? "Codice non disponibile" : revisione.getCodiceSorgente());
    }

    private boolean corrispondeAiFiltri(Attivita attivita) {
        Progetto progetto = (Progetto) cmbFiltroProgetto.getSelectedItem();
        if (progetto != null && progetto.getIdProg() != attivita.getIdProg()) return false;
        String stato = (String) cmbFiltroStato.getSelectedItem();
        if (stato != null && !"Tutti gli stati".equals(stato) && !stato.equals(attivita.getStato())) return false;
        String tipo = (String) cmbFiltroTipo.getSelectedItem();
        if (tipo != null && !"Tutti i tipi".equals(tipo) && !tipo.equals(attivita.getTipoAttivita())) return false;
        String scadenza = (String) cmbFiltroScadenza.getSelectedItem();
        LocalDate oggi = LocalDate.now();
        LocalDate data = attivita.getDataScadenza() == null ? null
                : new java.sql.Date(attivita.getDataScadenza().getTime()).toLocalDate();
        if ("Senza scadenza".equals(scadenza) && data != null) return false;
        if ("Scadute".equals(scadenza) && (data == null || !data.isBefore(oggi))) return false;
        if ("Entro 7 giorni".equals(scadenza) && (data == null || data.isBefore(oggi) || data.isAfter(oggi.plusDays(7)))) return false;
        Utente membro = (Utente) cmbFiltroMembro.getSelectedItem();
        if (membro != null && !assegnatariPerAttivita.getOrDefault(attivita.getIdAttivita(), List.of()).contains(membro.getMatricola())) return false;
        return true;
    }

    private JPanel creaCardTask(Attivita a) {
        LoginFrame.RoundedPanel card = new LoginFrame.RoundedPanel(15, Color.WHITE);
        card.setLayout(new BorderLayout(10, 10));
        card.setBorder(new EmptyBorder(12, 15, 12, 15));

        JLabel lblTitolo = new JLabel(a.getTitolo());
        lblTitolo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTitolo.setForeground(COLOR_PRIMARY);

        JLabel lblDesc = new JLabel("<html>" + (a.getDescrizione() != null ? a.getDescrizione() : "Nessuna descrizione") + "</html>");
        lblDesc.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JPanel pnlRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        pnlRight.setOpaque(false);
        pnlRight.add(creaPulsanteStato(a));
        LoginFrame.RoundedButton apri = new LoginFrame.RoundedButton("Apri", 10,
                new Color(236, 242, 249), new Color(222, 232, 244), COLOR_PRIMARY);
        apri.setPreferredSize(new Dimension(78, 34));
        apri.setEnabled(!"Finito".equals(a.getStato()));
        apri.setToolTipText("Finito".equals(a.getStato()) ? "Le attività concluse sono bloccate" : "Apri attività");
        apri.addActionListener(e -> {
            Attivita aggiornata = attivitaDAO.getAttivitaById(a.getIdAttivita());
            if (aggiornata == null || "Finito".equals(aggiornata.getStato())) {
                caricaTask();
                return;
            }
            new AttivitaDettaglioDialog((Frame) SwingUtilities.getWindowAncestor(this),
                    utente, aggiornata, this::caricaTask).mostra();
        });
        pnlRight.add(apri);

        String scadenza = a.getDataScadenza() == null ? "Senza scadenza"
                : "Scadenza: " + new java.text.SimpleDateFormat("dd/MM/yyyy").format(a.getDataScadenza());
        JLabel lblInfo = new JLabel(a.getTipoAttivita() + "  ·  " + scadenza);
        lblInfo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblInfo.setForeground(new Color(100, 100, 100));
        JPanel pnlFooter = new JPanel(new BorderLayout());
        pnlFooter.setOpaque(false);
        pnlFooter.add(lblInfo, BorderLayout.WEST);
        pnlFooter.add(pnlRight, BorderLayout.EAST);

        card.add(lblTitolo, BorderLayout.NORTH);
        card.add(lblDesc, BorderLayout.CENTER);
        card.add(pnlFooter, BorderLayout.SOUTH);

        return card;
    }

    private JButton creaPulsanteStato(Attivita attivita) {
        String stato = attivita.getStato();
        String etichetta;
        Color colore;
        Color sfondo;
        Color hover;
        String tooltip;

        if ("Finito".equals(stato)) {
            etichetta = "Finito";
            colore = new Color(35, 123, 70);
            sfondo = new Color(225, 244, 232);
            hover = new Color(225, 244, 232);
            tooltip = "Task completata";
        } else if ("In Corso".equals(stato)) {
            etichetta = "In Corso";
            colore = new Color(191, 105, 0);
            sfondo = new Color(255, 242, 220);
            hover = new Color(255, 232, 193);
            tooltip = "Clicca per segnare la task come finita";
        } else {
            etichetta = "Iniziato";
            colore = new Color(166, 44, 58);
            sfondo = new Color(255, 234, 236);
            hover = new Color(255, 221, 224);
            tooltip = "Clicca per avviare la task";
        }

        LoginFrame.RoundedButton pulsante = new LoginFrame.RoundedButton("●  " + etichetta, 12, sfondo, hover, colore);
        pulsante.setPreferredSize(new Dimension(132, 34));
        pulsante.setToolTipText(tooltip);
        pulsante.addActionListener(e -> {
            if ("Finito".equals(attivita.getStato())) {
                return;
            }
            String nuovoStato = "Iniziato".equals(attivita.getStato()) ? "In Corso" : "Finito";
            if (attivitaDAO.aggiornaStatoAttivita(attivita.getIdAttivita(), nuovoStato)) {
                attivita.setStato(nuovoStato);
                caricaTask();
            } else {
                mostraErroreAggiornamentoStato();
            }
        });
        if ("Finito".equals(stato)) {
            pulsante.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            pulsante.setEnabled(false);
        }
        return pulsante;
    }

    private void mostraErroreAggiornamentoStato() {
        CustomDialog dialog = new CustomDialog((Frame) SwingUtilities.getWindowAncestor(this), "Aggiornamento task");
        JPanel content = dialog.getContentPanel();
        content.setLayout(new BorderLayout(0, 12));
        JLabel messaggio = new JLabel("Non è stato possibile aggiornare lo stato della task.");
        messaggio.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        content.add(messaggio, BorderLayout.CENTER);
        JPanel azioni = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        azioni.setOpaque(false);
        LoginFrame.RoundedButton chiudi = new LoginFrame.RoundedButton("Chiudi", 10);
        chiudi.addActionListener(e -> dialog.dispose());
        azioni.add(chiudi);
        content.add(azioni, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void mostraDialogCreaTask() {
        List<Progetto> progetti = progettoDAO.getProgettiPerUtente(utente.getMatricola());
        if (progetti.isEmpty()) {
            CustomDialog avviso = new CustomDialog((Frame) SwingUtilities.getWindowAncestor(this), "Crea Nuovo Task");
            avviso.getContentPanel().setLayout(new BorderLayout(0, 10));
            avviso.getContentPanel().add(new JLabel("Devi prima creare o far parte di un progetto."), BorderLayout.CENTER);
            LoginFrame.RoundedButton chiudi = new LoginFrame.RoundedButton("Chiudi", 10);
            chiudi.addActionListener(e -> avviso.dispose());
            JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT)); footer.setOpaque(false); footer.add(chiudi);
            avviso.getContentPanel().add(footer, BorderLayout.SOUTH);
            avviso.pack(); avviso.setLocationRelativeTo(this); avviso.setVisible(true);
            return;
        }

        JTextField txtTitolo = new JTextField();
        JTextArea txtDesc = new JTextArea(3, 20);
        JComboBox<Progetto> cmbProgetti = new JComboBox<>(progetti.toArray(new Progetto[0]));
        cmbProgetti.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Progetto) setText(((Progetto) value).getNome());
                return this;
            }
        });
        JComboBox<String> cmbTipo = new JComboBox<>(new String[]{"Documentazione", "Sviluppo"});
        CustomDialog dialog = new CustomDialog((Frame) SwingUtilities.getWindowAncestor(this), "Crea Nuovo Task");
        JTextArea txtCodiceModulo = new JTextArea(5, 35);
        txtCodiceModulo.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        txtCodiceModulo.setTabSize(4);
        JTextField txtUrlDocumento = new JTextField();
        File[] documentoSelezionato = new File[1];
        JPanel campoDocumento = new JPanel(new BorderLayout(6, 0));
        campoDocumento.setOpaque(false);
        LoginFrame.RoundedButton scegliDocumento = new LoginFrame.RoundedButton("Scegli file", 9,
                new Color(236, 242, 249), new Color(222, 232, 244), COLOR_PRIMARY);
        scegliDocumento.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(dialog) == JFileChooser.APPROVE_OPTION) {
                documentoSelezionato[0] = chooser.getSelectedFile();
                txtUrlDocumento.setText(documentoSelezionato[0].getAbsolutePath());
            }
        });
        campoDocumento.add(txtUrlDocumento, BorderLayout.CENTER);
        campoDocumento.add(scegliDocumento, BorderLayout.EAST);
        DatePickerField txtScadenza = new DatePickerField();
        DefaultListModel<Utente> modelloResponsabili = new DefaultListModel<>();
        JList<Utente> listaResponsabili = new JList<>(modelloResponsabili);
        listaResponsabili.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        listaResponsabili.setCellRenderer((list, value, index, selected, focus) -> {
            JLabel label = new JLabel(value.getNome() + " " + value.getCognome() + " · " + value.getMatricola());
            label.setOpaque(true);
            label.setBackground(selected ? list.getSelectionBackground() : list.getBackground());
            label.setForeground(selected ? list.getSelectionForeground() : list.getForeground());
            label.setBorder(new EmptyBorder(3, 6, 3, 6));
            return label;
        });
        JPanel content = dialog.getContentPanel(); content.setLayout(new BorderLayout(0, 8));
        JPanel form = new JPanel(new GridBagLayout()); form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints(); gbc.gridx = 0; gbc.gridy = 0;
        gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.insets = new Insets(5, 0, 5, 0);
        aggiungiCampo(form, gbc, "Titolo task", txtTitolo);
        txtDesc.setLineWrap(true); txtDesc.setWrapStyleWord(true); txtDesc.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        aggiungiCampo(form, gbc, "Descrizione", new JScrollPane(txtDesc));
        aggiungiCampo(form, gbc, "Progetto", cmbProgetti);
        aggiungiCampo(form, gbc, "Scadenza (facoltativa)", txtScadenza);
        aggiungiCampo(form, gbc, "Responsabili", new JScrollPane(listaResponsabili));
        aggiungiCampo(form, gbc, "Tipo task", cmbTipo);
        JPanel dinamico = new JPanel(new BorderLayout(0, 5)); dinamico.setOpaque(false);
        JLabel lblDinamica = new JLabel(); dinamico.add(lblDinamica, BorderLayout.NORTH);
        gbc.gridy++; form.add(dinamico, gbc);
        Runnable aggiornaTipi = () -> {
            Progetto selezionato = (Progetto) cmbProgetti.getSelectedItem();
            boolean sviluppo = selezionato != null && "Sviluppo".equals(selezionato.getTipoProgetto());
            String tipoPrecedente = (String) cmbTipo.getSelectedItem();
            cmbTipo.removeAllItems();
            cmbTipo.addItem(sviluppo ? "Sviluppo" : "Documentazione");
            if (tipoPrecedente != null && tipoPrecedente.equals(cmbTipo.getItemAt(0))) {
                cmbTipo.setSelectedItem(tipoPrecedente);
            }
        };
        Runnable aggiornaResponsabili = () -> {
            modelloResponsabili.clear();
            Progetto selezionato = (Progetto) cmbProgetti.getSelectedItem();
            if (selezionato != null) {
                for (Utente membro : utenteDAO.getUtentiPartecipantiProgetto(selezionato.getIdProg())) {
                    modelloResponsabili.addElement(membro);
                }
            }
        };
        Runnable aggiornaCampo = () -> {
            dinamico.removeAll(); String tipo = (String) cmbTipo.getSelectedItem();
            if ("Sviluppo".equals(tipo)) {
                lblDinamica.setText("Codice sorgente (obbligatorio)"); dinamico.add(lblDinamica, BorderLayout.NORTH); dinamico.add(new JScrollPane(txtCodiceModulo), BorderLayout.CENTER);
            } else if ("Documentazione".equals(tipo)) {
                lblDinamica.setText("Documento o URL (obbligatorio)"); dinamico.add(lblDinamica, BorderLayout.NORTH); dinamico.add(campoDocumento, BorderLayout.CENTER);
            }
            dinamico.revalidate(); dinamico.repaint(); dialog.pack(); dialog.setLocationRelativeTo(this);
        };
        cmbTipo.addActionListener(e -> aggiornaCampo.run());
        cmbProgetti.addActionListener(e -> { aggiornaTipi.run(); aggiornaResponsabili.run(); aggiornaCampo.run(); });
        aggiornaTipi.run(); aggiornaResponsabili.run(); aggiornaCampo.run();
        JLabel lblErrore = new JLabel(" "); lblErrore.setForeground(new Color(180, 45, 45)); lblErrore.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JPanel footer = new JPanel(new BorderLayout()); footer.setOpaque(false); footer.add(lblErrore, BorderLayout.NORTH);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4)); actions.setOpaque(false);
        LoginFrame.RoundedButton annulla = new LoginFrame.RoundedButton("Annulla", 10,
                new Color(236, 242, 249), new Color(222, 232, 244), COLOR_PRIMARY);
        annulla.addActionListener(e -> dialog.dispose());
        LoginFrame.RoundedButton conferma = new LoginFrame.RoundedButton("Crea", 10);
        conferma.addActionListener(e -> {
            String titolo = txtTitolo.getText().trim(); Progetto pSel = (Progetto) cmbProgetti.getSelectedItem();
            String descrizione = pulisci(txtDesc.getText());
            if (titolo.isEmpty() || titolo.length() > 30 || descrizione == null || descrizione.length() > 255 || pSel == null || listaResponsabili.getSelectedValue() == null) {
                lblErrore.setText("Inserisci titolo, descrizione, progetto e almeno un responsabile."); return;
            }
            java.util.Date scadenza = null;
            if (!txtScadenza.getText().trim().isEmpty()) {
                try {
                    scadenza = java.sql.Date.valueOf(LocalDate.parse(txtScadenza.getText().trim(), DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                } catch (DateTimeParseException ex) {
                    lblErrore.setText("Inserisci la scadenza nel formato gg/mm/aaaa."); return;
                }
            }
            if (scadenza != null && pSel.getDataScadenza() != null && scadenza.after(pSel.getDataScadenza())) {
                lblErrore.setText("La scadenza del task non può superare quella del progetto."); return;
            }
            String tipo = (String) cmbTipo.getSelectedItem();
            String codiceModulo = "Sviluppo".equals(tipo) ? pulisci(txtCodiceModulo.getText()) : null;
            String urlDocumento = null;
            if ("Documentazione".equals(tipo)) {
                urlDocumento = pulisci(txtUrlDocumento.getText());
                if (documentoSelezionato[0] != null) {
                    try {
                        urlDocumento = DocumentoTask.codifica(documentoSelezionato[0]);
                    } catch (IOException ex) {
                        lblErrore.setText("Non è stato possibile leggere il documento selezionato."); return;
                    }
                }
            }
            if (("Sviluppo".equals(tipo) && codiceModulo == null) || ("Documentazione".equals(tipo) && urlDocumento == null)) {
                lblErrore.setText("Compila il campo obbligatorio per il tipo di attività."); return;
            }
            Attivita a = new Attivita(0, titolo, descrizione, new java.util.Date(), scadenza, "Iniziato", tipo, codiceModulo, urlDocumento, pSel.getIdProg());
            if (!attivitaDAO.creaAttivita(a)) {
                lblErrore.setText("Errore nella creazione del task.");
                return;
            }
            List<String> responsabili = new ArrayList<>();
            for (Utente membro : listaResponsabili.getSelectedValuesList()) responsabili.add(membro.getMatricola());
            if (!attivitaDAO.aggiornaAssegnatari(a, responsabili)) {
                lblErrore.setText("Task creata, ma i responsabili non sono stati salvati. Riaprila per riprovare.");
                caricaTask();
                return;
            }
            if ("Sviluppo".equals(tipo) && codiceModulo != null
                    && !revisioneDAO.salvaCodiceConRevisione(a.getIdAttivita(), codiceModulo,
                    "Creazione iniziale del codice sorgente", utente.getMatricola())) {
                lblErrore.setText("Task creata, ma la revisione iniziale del codice non è stata salvata.");
                caricaTask();
                return;
            }
            dialog.dispose();
            caricaTask();
        });
        actions.add(annulla); actions.add(conferma); footer.add(actions, BorderLayout.SOUTH);
        content.add(form, BorderLayout.CENTER); content.add(footer, BorderLayout.SOUTH);
        dialog.pack(); dialog.setLocationRelativeTo(this); dialog.setVisible(true);
    }

    private void aggiungiCampo(JPanel form, GridBagConstraints gbc, String titolo, JComponent campo) {
        JPanel riga = new JPanel(new BorderLayout(0, 5)); riga.setOpaque(false);
        JLabel label = new JLabel(titolo); label.setFont(new Font("Segoe UI", Font.PLAIN, 12)); label.setForeground(COLOR_PRIMARY);
        campo.setFont(new Font("Segoe UI", Font.PLAIN, 13)); riga.add(label, BorderLayout.NORTH); riga.add(campo, BorderLayout.CENTER);
        form.add(riga, gbc); gbc.gridy++;
    }

    private String pulisci(String valore) { String pulito = valore == null ? "" : valore.trim(); return pulito.isEmpty() ? null : pulito; }
}
