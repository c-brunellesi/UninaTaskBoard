package UninaTaskBoard_GUI;

import UninaTaskBoard_DAO.InvitoDAO;
import UninaTaskBoard_DAO.ProgettoDAO;
import UninaTaskBoard_DAO.UtenteDAO;
import UninaTaskBoard_Model.Invito;
import UninaTaskBoard_Model.Progetto;
import UninaTaskBoard_Model.Utente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class InvitiPanel extends JPanel {
    private final Utente utente;
    private final MainFrame mainFrame;
    private final InvitoDAO invitoDAO = new InvitoDAO();
    private final ProgettoDAO progettoDAO = new ProgettoDAO();
    private final UtenteDAO utenteDAO = new UtenteDAO();
    private final JPanel contenuto = new JPanel();
    private final Color primary = new Color(0, 28, 99);
    private final Color background = new Color(245, 247, 250);

    public InvitiPanel(Utente utente, MainFrame mainFrame) {
        this.utente = utente;
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout(15, 15));
        setBackground(background);
        setBorder(new EmptyBorder(25, 25, 25, 25));
        JLabel titolo = new JLabel("INVITI AI PROGETTI");
        titolo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titolo.setForeground(primary);
        add(titolo, BorderLayout.NORTH);
        contenuto.setOpaque(false);
        contenuto.setLayout(new BoxLayout(contenuto, BoxLayout.Y_AXIS));
        JScrollPane scroll = new JScrollPane(contenuto);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        add(scroll, BorderLayout.CENTER);
        caricaInviti();
    }

    public void caricaInviti() {
        contenuto.removeAll();
        aggiungiTitoloSezione("Inviti ricevuti");
        List<Invito> ricevuti = invitoDAO.getInvitiRicevutiPendenti(utente.getMatricola());
        if (ricevuti.isEmpty()) aggiungiMessaggio("Non hai inviti in attesa.");
        for (Invito invito : ricevuti) contenuto.add(creaInvitoRicevuto(invito));

        contenuto.add(Box.createVerticalStrut(18));
        aggiungiTitoloSezione("Inviti inviati");
        List<Invito> inviati = invitoDAO.getInvitiInviati(utente.getMatricola());
        if (inviati.isEmpty()) aggiungiMessaggio("Non hai ancora inviato inviti.");
        for (Invito invito : inviati) contenuto.add(creaInvitoInviato(invito));
        contenuto.revalidate();
        contenuto.repaint();
        mainFrame.aggiornaBadgeMenu();
    }

    private void aggiungiTitoloSezione(String testo) {
        JLabel label = new JLabel(testo);
        label.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label.setForeground(primary);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setBorder(new EmptyBorder(0, 0, 10, 0));
        contenuto.add(label);
    }

    private void aggiungiMessaggio(String testo) {
        JLabel label = new JLabel(testo);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        label.setForeground(new Color(90, 98, 108));
        label.setBorder(new EmptyBorder(4, 2, 12, 2));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        contenuto.add(label);
    }

    private JPanel creaInvitoRicevuto(Invito invito) {
        Utente mittente = utenteDAO.getUtenteByMatricola(invito.getMatricolaInvitante());
        Progetto progetto = progettoDAO.getProgettoById(invito.getIdProg());
        String nomeMittente = mittente == null ? invito.getMatricolaInvitante()
                : mittente.getNome() + " " + mittente.getCognome();
        String nomeProgetto = progetto == null ? "Progetto non disponibile" : progetto.getNome();
        LoginFrame.RoundedPanel card = creaCard();
        card.setLayout(new BorderLayout(10, 8));
        JLabel testo = new JLabel("<html><b>" + escape(nomeMittente) + "</b> ti invita al progetto <b>"
                + escape(nomeProgetto) + "</b>.</html>");
        testo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        card.add(testo, BorderLayout.CENTER);
        JPanel azioni = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        azioni.setOpaque(false);
        LoginFrame.RoundedButton rifiuta = new LoginFrame.RoundedButton("Rifiuta", 9,
                new Color(236, 242, 249), new Color(222, 232, 244), primary);
        LoginFrame.RoundedButton accetta = new LoginFrame.RoundedButton("Accetta", 9);
        rifiuta.addActionListener(e -> {
            if (invitoDAO.rifiutaInvito(invito.getIdInvito())) caricaInviti();
            else messaggio("Non è stato possibile rifiutare l'invito. Aggiorna la schermata e riprova.");
        });
        accetta.addActionListener(e -> {
            if (invitoDAO.accettaInvito(invito.getIdInvito(), utente.getMatricola(), invito.getIdProg())) {
                caricaInviti();
                messaggio("Hai accettato l'invito. Il progetto è ora disponibile tra i tuoi progetti.");
            } else {
                messaggio("Invito non più valido oppure il progetto è scaduto. Aggiorna la schermata e riprova.");
                caricaInviti();
            }
        });
        azioni.add(rifiuta);
        azioni.add(accetta);
        card.add(azioni, BorderLayout.SOUTH);
        return card;
    }

    private JPanel creaInvitoInviato(Invito invito) {
        Utente destinatario = utenteDAO.getUtenteByMatricola(invito.getMatricolaDestinatario());
        Progetto progetto = progettoDAO.getProgettoById(invito.getIdProg());
        String nomeDestinatario = destinatario == null ? invito.getMatricolaDestinatario()
                : destinatario.getNome() + " " + destinatario.getCognome();
        String nomeProgetto = progetto == null ? "Progetto non disponibile" : progetto.getNome();
        LoginFrame.RoundedPanel card = creaCard();
        card.setLayout(new BorderLayout(10, 8));
        JLabel testo = new JLabel("<html>Invito per <b>" + escape(nomeDestinatario) + "</b> nel progetto <b>"
                + escape(nomeProgetto) + "</b></html>");
        testo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JLabel stato = new JLabel(invito.getStato());
        stato.setFont(new Font("Segoe UI", Font.BOLD, 12));
        stato.setForeground("Accettato".equals(invito.getStato()) ? new Color(35, 130, 75)
                : "Rifiutato".equals(invito.getStato()) ? new Color(180, 55, 55) : new Color(190, 120, 20));
        card.add(testo, BorderLayout.CENTER);
        card.add(stato, BorderLayout.EAST);
        return card;
    }

    private LoginFrame.RoundedPanel creaCard() {
        LoginFrame.RoundedPanel card = new LoginFrame.RoundedPanel(14, Color.WHITE);
        card.setBorder(new EmptyBorder(14, 16, 14, 16));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        return card;
    }

    private String escape(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    private void messaggio(String testo) {
        CustomDialog dialog = new CustomDialog((Frame) SwingUtilities.getWindowAncestor(this), "Inviti");
        JPanel content = dialog.getContentPanel();
        content.setLayout(new BorderLayout(0, 12));
        JLabel label = new JLabel("<html>" + escape(testo) + "</html>");
        label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        content.add(label, BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);
        LoginFrame.RoundedButton chiudi = new LoginFrame.RoundedButton("Chiudi", 10);
        chiudi.addActionListener(e -> dialog.dispose());
        actions.add(chiudi);
        content.add(actions, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
}
