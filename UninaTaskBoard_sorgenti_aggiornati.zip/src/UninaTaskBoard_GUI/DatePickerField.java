package UninaTaskBoard_GUI;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

public class DatePickerField extends JPanel {
    private static final Color PRIMARY = new Color(0, 28, 99);
    private static final Color BACKGROUND = new Color(245, 247, 250);
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private final JTextField campo = new JTextField();
    private final JButton pulsante = new LoginFrame.RoundedButton("", 8,
            new Color(236, 242, 249), new Color(222, 232, 244), PRIMARY);
    private LocalDate meseVisualizzato = LocalDate.now().withDayOfMonth(1);

    public DatePickerField() {
        super(new BorderLayout(6, 0));
        setOpaque(false);
        campo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        campo.setToolTipText("Formato gg/mm/aaaa");
        pulsante.setIcon(new CalendarIcon(PRIMARY));
        pulsante.setPreferredSize(new Dimension(38, 32));
        pulsante.setToolTipText("Apri calendario");
        pulsante.getAccessibleContext().setAccessibleName("Apri calendario");
        pulsante.addActionListener(e -> mostraCalendario());
        add(campo, BorderLayout.CENTER);
        add(pulsante, BorderLayout.EAST);
    }

    public String getText() {
        return campo.getText();
    }

    public void setText(String valore) {
        campo.setText(valore);
    }

    public void setDate(Date data) {
        campo.setText(data == null ? "" : new java.sql.Date(data.getTime()).toLocalDate().format(FORMATTER));
    }

    private void mostraCalendario() {
        try {
            LocalDate corrente = LocalDate.parse(campo.getText().trim(), FORMATTER);
            meseVisualizzato = corrente.withDayOfMonth(1);
        } catch (DateTimeParseException e) {
            meseVisualizzato = LocalDate.now().withDayOfMonth(1);
        }
        JPopupMenu popup = new JPopupMenu();
        popup.setBorder(BorderFactory.createLineBorder(new Color(200, 215, 230)));
        popup.add(creaCalendario(popup));
        popup.show(this, 0, getHeight());
    }

    private JPanel creaCalendario(JPopupMenu popup) {
        JPanel pannello = new JPanel(new BorderLayout(4, 6));
        pannello.setBackground(Color.WHITE);
        pannello.setBorder(new EmptyBorder(8, 8, 8, 8));
        JPanel intestazione = new JPanel(new BorderLayout(8, 0));
        intestazione.setOpaque(false);
        JButton precedente = pulsanteMese("‹");
        JButton successivo = pulsanteMese("›");
        JLabel titolo = new JLabel(meseVisualizzato.getMonth().getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.ITALIAN)
                + " " + meseVisualizzato.getYear(), SwingConstants.CENTER);
        titolo.setFont(new Font("Segoe UI", Font.BOLD, 13));
        titolo.setForeground(PRIMARY);
        precedente.addActionListener(e -> { meseVisualizzato = meseVisualizzato.minusMonths(1); aggiornaCalendario(popup); });
        successivo.addActionListener(e -> { meseVisualizzato = meseVisualizzato.plusMonths(1); aggiornaCalendario(popup); });
        intestazione.add(precedente, BorderLayout.WEST);
        intestazione.add(titolo, BorderLayout.CENTER);
        intestazione.add(successivo, BorderLayout.EAST);
        pannello.add(intestazione, BorderLayout.NORTH);
        JPanel griglia = new JPanel(new GridLayout(7, 7, 2, 2));
        griglia.setOpaque(false);
        String[] giorni = {"L", "M", "M", "G", "V", "S", "D"};
        for (String giorno : giorni) {
            JLabel label = new JLabel(giorno, SwingConstants.CENTER);
            label.setFont(new Font("Segoe UI", Font.BOLD, 11));
            label.setForeground(new Color(105, 115, 128));
            griglia.add(label);
        }
        LocalDate primo = meseVisualizzato.withDayOfMonth(1);
        int vuoti = primo.getDayOfWeek().getValue() - 1;
        for (int i = 0; i < vuoti; i++) griglia.add(new JLabel(""));
        int giorniNelMese = YearMonth.from(primo).lengthOfMonth();
        for (int giorno = 1; giorno <= giorniNelMese; giorno++) {
            LocalDate data = primo.withDayOfMonth(giorno);
            JButton giornoButton = new JButton(Integer.toString(giorno));
            giornoButton.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            giornoButton.setForeground(PRIMARY);
            giornoButton.setBackground(data.equals(LocalDate.now()) ? new Color(222, 235, 250) : BACKGROUND);
            giornoButton.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            giornoButton.setFocusPainted(false);
            giornoButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            giornoButton.addActionListener(e -> { campo.setText(data.format(FORMATTER)); popup.setVisible(false); });
            griglia.add(giornoButton);
        }
        pannello.add(griglia, BorderLayout.CENTER);
        return pannello;
    }

    private void aggiornaCalendario(JPopupMenu popup) {
        popup.removeAll();
        popup.add(creaCalendario(popup));
        popup.setPopupSize(popup.getPreferredSize());
        popup.revalidate();
        popup.repaint();
    }

    private JButton pulsanteMese(String testo) {
        JButton button = new JButton(testo);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(PRIMARY);
        button.setBackground(BACKGROUND);
        button.setBorder(BorderFactory.createEmptyBorder(3, 10, 3, 10));
        button.setFocusPainted(false);
        return button;
    }

    private static class CalendarIcon implements Icon {
        private final Color color;
        private CalendarIcon(Color color) { this.color = color; }
        public int getIconWidth() { return 16; }
        public int getIconHeight() { return 16; }
        public void paintIcon(Component component, Graphics graphics, int x, int y) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.translate(x, y);
            g.setColor(color);
            g.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.drawRoundRect(1, 3, 14, 12, 2, 2);
            g.drawLine(1, 6, 15, 6);
            g.drawLine(5, 1, 5, 5);
            g.drawLine(11, 1, 11, 5);
            g.fillRoundRect(4, 8, 2, 2, 1, 1);
            g.fillRoundRect(8, 8, 2, 2, 1, 1);
            g.fillRoundRect(4, 11, 2, 2, 1, 1);
            g.fillRoundRect(8, 11, 2, 2, 1, 1);
            g.dispose();
        }
    }
}
