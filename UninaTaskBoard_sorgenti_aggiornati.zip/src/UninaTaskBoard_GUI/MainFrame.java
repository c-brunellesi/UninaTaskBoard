package UninaTaskBoard_GUI;

import UninaTaskBoard_DAO.InvitoDAO;
import UninaTaskBoard_DAO.NotificaDAO;
import UninaTaskBoard_Model.Utente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainFrame extends JFrame {

    private Utente utenteCorrente;

    private CardLayout cardLayout;
    private JPanel contentPanel;

    private DashboardPanel dashboardPanel;
    private ProgettiPanel progettiPanel;
    private TaskPanel taskPanel;
    private InvitiPanel invitiPanel;
    private NotifichePanel notifichePanel;
    private ReportPanel reportPanel;
    private final Map<String, LoginFrame.RoundedButton> pulsantiNavigazione = new LinkedHashMap<>();
    private final Map<String, BadgeLabel> badgeNavigazione = new LinkedHashMap<>();
    private final NotificaDAO notificaDAO = new NotificaDAO();
    private final InvitoDAO invitoDAO = new InvitoDAO();
    private String sezioneAttiva;
    private Timer timerBadge;

    private final Color COLOR_BG_SIDEBAR = new Color(232, 240, 249);
    private final Color COLOR_PRIMARY = new Color(0, 28, 99);
    private final Color COLOR_NAV_ACTIVE = new Color(207, 224, 243);
    private final Color COLOR_TEXT_MAIN = new Color(0, 28, 99);

    public MainFrame(Utente utente) {
        this.utenteCorrente = utente;

        setTitle("UninaTaskBoard - Sistema Gestionale");
        setIconImage(LoginFrame.caricaLogoIcona(512));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1100, 720));
        setSize(1280, 800);
        setLocationRelativeTo(null);

        JPanel mainContainer = new JPanel(new BorderLayout());
        mainContainer.setBackground(Color.WHITE);

        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(new Color(245, 247, 250));

        dashboardPanel = new DashboardPanel(utenteCorrente, this);
        progettiPanel = new ProgettiPanel(utenteCorrente, this);
        taskPanel = new TaskPanel(utenteCorrente, this);
        invitiPanel = new InvitiPanel(utenteCorrente, this);
        notifichePanel = new NotifichePanel(utenteCorrente, this);
        reportPanel = new ReportPanel(utenteCorrente);

        contentPanel.add(dashboardPanel, "DASHBOARD");
        contentPanel.add(progettiPanel, "PROGETTI");
        contentPanel.add(taskPanel, "TASKS");
        contentPanel.add(invitiPanel, "INVITI");
        contentPanel.add(notifichePanel, "NOTIFICHE");
        contentPanel.add(reportPanel, "REPORT");

        JPanel sidebarPanel = creaSidebar();

        mainContainer.add(sidebarPanel, BorderLayout.WEST);
        mainContainer.add(contentPanel, BorderLayout.CENTER);

        add(mainContainer);

        mostraSezione("DASHBOARD");
        aggiornaBadgeMenu();
        timerBadge = new Timer(15000, e -> aggiornaBadgeMenu());
        timerBadge.start();
    }

    private JPanel creaSidebar() {
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setPreferredSize(new Dimension(252, 0));
        sidebar.setBackground(COLOR_BG_SIDEBAR);
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(200, 215, 230)));

        JPanel pnlHeader = new JPanel();
        pnlHeader.setLayout(new BoxLayout(pnlHeader, BoxLayout.Y_AXIS));
        pnlHeader.setOpaque(false);
        pnlHeader.setBorder(new EmptyBorder(22, 15, 18, 15));

        Image logo = LoginFrame.caricaLogoSidebarIcona(130);
        JLabel lblLogo = new JLabel(logo == null ? null : new ImageIcon(logo), SwingConstants.CENTER);
        lblLogo.setPreferredSize(new Dimension(150, 130));
        lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblUser = new JLabel(utenteCorrente.getNome() + " " + utenteCorrente.getCognome(), SwingConstants.CENTER);
        lblUser.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblUser.setForeground(new Color(60, 60, 60));
        lblUser.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblMatricola = new JLabel("Matricola " + utenteCorrente.getMatricola(), SwingConstants.CENTER);
        lblMatricola.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblMatricola.setForeground(new Color(100, 100, 100));
        lblMatricola.setAlignmentX(Component.CENTER_ALIGNMENT);

        pnlHeader.add(lblLogo);
        pnlHeader.add(Box.createRigidArea(new Dimension(0, 10)));
        pnlHeader.add(lblUser);
        pnlHeader.add(lblMatricola);

        JPanel pnlMenu = new JPanel();
        pnlMenu.setLayout(new BoxLayout(pnlMenu, BoxLayout.Y_AXIS));
        pnlMenu.setOpaque(false);
        pnlMenu.setBorder(new EmptyBorder(10, 12, 10, 12));

        pnlMenu.add(creaNavItem("▦   Dashboard", "DASHBOARD", false));
        pnlMenu.add(Box.createRigidArea(new Dimension(0, 6)));
        pnlMenu.add(creaNavItem("▤   I Miei Progetti", "PROGETTI", false));
        pnlMenu.add(Box.createRigidArea(new Dimension(0, 6)));
        pnlMenu.add(creaNavItem("✓   I Miei Task", "TASKS", false));
        pnlMenu.add(Box.createRigidArea(new Dimension(0, 6)));
        pnlMenu.add(creaNavItem("✉   Inviti", "INVITI", true));
        pnlMenu.add(Box.createRigidArea(new Dimension(0, 6)));
        pnlMenu.add(creaNavItem("◉   Notifiche", "NOTIFICHE", true));
        pnlMenu.add(Box.createRigidArea(new Dimension(0, 6)));
        pnlMenu.add(creaNavItem("▥   Report", "REPORT", false));

        JPanel pnlFooter = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pnlFooter.setOpaque(false);
        pnlFooter.setBorder(new EmptyBorder(15, 12, 20, 12));

        LoginFrame.RoundedButton btnLogout = new LoginFrame.RoundedButton("Logout", 10);
        btnLogout.setPreferredSize(new Dimension(200, 36));
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnLogout.addActionListener(e -> confermALogout());

        pnlFooter.add(btnLogout);

        sidebar.add(pnlHeader, BorderLayout.NORTH);
        sidebar.add(pnlMenu, BorderLayout.CENTER);
        sidebar.add(pnlFooter, BorderLayout.SOUTH);

        return sidebar;
    }

    private JPanel creaNavItem(String testo, String cardName, boolean conBadge) {
        JPanel riga = new JPanel(new BorderLayout(4, 0));
        riga.setOpaque(false);
        riga.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        riga.add(creaNavButton(testo, cardName), BorderLayout.CENTER);
        if (conBadge) {
            BadgeLabel badge = new BadgeLabel();
            badge.setVisible(false);
            badgeNavigazione.put(cardName, badge);
            riga.add(badge, BorderLayout.EAST);
        }
        return riga;
    }

    private JButton creaNavButton(String testo, String cardName) {
        LoginFrame.RoundedButton btn = new LoginFrame.RoundedButton(testo, 10,
                COLOR_BG_SIDEBAR, COLOR_NAV_ACTIVE, COLOR_PRIMARY);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btn.setPreferredSize(new Dimension(200, 40));
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(COLOR_PRIMARY);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addActionListener(e -> mostraSezione(cardName));
        pulsantiNavigazione.put(cardName, btn);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(COLOR_NAV_ACTIVE);
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(cardName.equals(sezioneAttiva) ? COLOR_NAV_ACTIVE : COLOR_BG_SIDEBAR);
            }
        });

        return btn;
    }

    public void mostraSezione(String cardName) {
        sezioneAttiva = cardName;
        for (Map.Entry<String, LoginFrame.RoundedButton> entry : pulsantiNavigazione.entrySet()) {
            boolean attivo = entry.getKey().equals(cardName);
            entry.getValue().setBackground(attivo ? COLOR_NAV_ACTIVE : COLOR_BG_SIDEBAR);
            entry.getValue().setForeground(COLOR_PRIMARY);
        }
        switch (cardName) {
            case "DASHBOARD":
                dashboardPanel.caricaDati();
                break;
            case "PROGETTI":
                progettiPanel.caricaProgetti();
                break;
            case "TASKS":
                taskPanel.caricaTask();
                break;
            case "INVITI":
                invitiPanel.caricaInviti();
                break;
            case "NOTIFICHE":
                notifichePanel.caricaNotifiche();
                break;
            case "REPORT":
                reportPanel.caricaReport();
                break;
        }
        cardLayout.show(contentPanel, cardName);
        aggiornaBadgeMenu();
    }

    public void aggiornaBadgeMenu() {
        BadgeLabel notifiche = badgeNavigazione.get("NOTIFICHE");
        if (notifiche != null) notifiche.setConteggio(notificaDAO.getConteggioNotificheNonLette(utenteCorrente.getMatricola()));
        BadgeLabel inviti = badgeNavigazione.get("INVITI");
        if (inviti != null) inviti.setConteggio(invitoDAO.getConteggioInvitiRicevutiPendenti(utenteCorrente.getMatricola()));
    }

    public void mostraAttivitaProgetto(int idProg) {
        taskPanel.selezionaProgetto(idProg);
        mostraSezione("TASKS");
    }

    private void confermALogout() {
        CustomDialog dialog = new CustomDialog(this, "Conferma Logout");
        JPanel content = dialog.getContentPanel();
        content.setLayout(new BorderLayout(0, 14));
        JLabel message = new JLabel("Sei sicuro di voler terminare la sessione?");
        message.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        content.add(message, BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4));
        actions.setOpaque(false);
        LoginFrame.RoundedButton annulla = new LoginFrame.RoundedButton("Annulla", 10,
                new Color(236, 242, 249), new Color(222, 232, 244), COLOR_PRIMARY);
        annulla.addActionListener(e -> dialog.dispose());
        LoginFrame.RoundedButton conferma = new LoginFrame.RoundedButton("Logout", 10);
        conferma.addActionListener(e -> {
            dialog.dispose();
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
            loginFrame.toFront();
            loginFrame.requestFocus();
            this.dispose();
        });
        actions.add(annulla);
        actions.add(conferma);
        content.add(actions, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    public Utente getUtenteCorrente() {
        return utenteCorrente;
    }

    @Override
    public void dispose() {
        if (timerBadge != null) timerBadge.stop();
        super.dispose();
    }

    private static class BadgeLabel extends JLabel {
        private final Color colore = new Color(204, 48, 56);

        private BadgeLabel() {
            setHorizontalAlignment(SwingConstants.CENTER);
            setVerticalAlignment(SwingConstants.CENTER);
            setFont(new Font("Segoe UI", Font.BOLD, 11));
            setForeground(Color.WHITE);
            setPreferredSize(new Dimension(26, 26));
            setOpaque(false);
        }

        private void setConteggio(int conteggio) {
            if (conteggio <= 0) {
                setVisible(false);
                return;
            }
            String valore = conteggio > 99 ? "99+" : Integer.toString(conteggio);
            setText(valore);
            setPreferredSize(new Dimension(valore.length() > 2 ? 32 : 26, 26));
            setVisible(true);
            revalidate();
            repaint();
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(colore);
            g.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
            g.dispose();
            super.paintComponent(graphics);
        }
    }
}
