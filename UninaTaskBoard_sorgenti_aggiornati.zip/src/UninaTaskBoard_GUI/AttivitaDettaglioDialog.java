package UninaTaskBoard_GUI;

import UninaTaskBoard_DAO.AttivitaDAO;
import UninaTaskBoard_DAO.CommentoDAO;
import UninaTaskBoard_DAO.RevisioneDAO;
import UninaTaskBoard_DAO.UtenteDAO;
import UninaTaskBoard_Model.Attivita;
import UninaTaskBoard_Model.Commento;
import UninaTaskBoard_Model.Revisione;
import UninaTaskBoard_Model.Utente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AttivitaDettaglioDialog {
    private final Frame proprietario;
    private final Utente utente;
    private final Attivita attivita;
    private final AttivitaDAO attivitaDAO = new AttivitaDAO();
    private final CommentoDAO commentoDAO = new CommentoDAO();
    private final RevisioneDAO revisioneDAO = new RevisioneDAO();
    private final UtenteDAO utenteDAO = new UtenteDAO();
    private final Runnable aggiornamento;
    private CustomDialog dialog;
    private JTextArea codice;
    private DefaultListModel<Revisione> modelloRevisioni;
    private JList<Revisione> elencoRevisioni;
    private JTextArea testoRevisione;
    private JLabel documentoCorrente;

    public AttivitaDettaglioDialog(Frame proprietario, Utente utente, Attivita attivita, Runnable aggiornamento) {
        this.proprietario = proprietario;
        this.utente = utente;
        this.attivita = attivita;
        this.aggiornamento = aggiornamento;
    }

    public void mostra() {
        Attivita aggiornata = attivitaDAO.getAttivitaById(attivita.getIdAttivita());
        if (aggiornata == null || "Finito".equals(aggiornata.getStato())) {
            mostraErrore("Questa attività è stata completata e non può più essere aperta o modificata.");
            aggiornamento.run();
            return;
        }
        dialog = new CustomDialog(proprietario, "Task: " + attivita.getTitolo());
        dialog.setPreferredSize(new Dimension(900, 680));
        JPanel content = dialog.getContentPanel();
        content.setLayout(new BorderLayout(0, 10));
        JTabbedPane schede = new JTabbedPane();
        schede.addTab("Dettagli e responsabili", creaDettagli());
        if ("Sviluppo".equals(attivita.getTipoAttivita())) {
            schede.addTab("Codice sorgente", creaEditorCodice());
            schede.addTab("Revisioni", creaRevisioni());
        } else {
            schede.addTab("Documento", creaDocumento());
        }
        schede.addTab("Commenti", creaCommenti());
        content.add(schede, BorderLayout.CENTER);
        dialog.pack();
        dialog.setSize(900, 680);
        dialog.setLocationRelativeTo(proprietario);
        dialog.setVisible(true);
    }

    private JPanel creaDettagli() {
        JPanel pannello = new JPanel(new BorderLayout(0, 12));
        pannello.setBorder(new EmptyBorder(15, 12, 10, 12));
        pannello.setOpaque(false);
        JTextArea descrizione = new JTextArea(attivita.getDescrizione());
        descrizione.setEditable(false);
        descrizione.setLineWrap(true);
        descrizione.setWrapStyleWord(true);
        descrizione.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        pannello.add(new JScrollPane(descrizione), BorderLayout.CENTER);
        List<Utente> membri = utenteDAO.getUtentiPartecipantiProgetto(attivita.getIdProg());
        DefaultListModel<Utente> model = new DefaultListModel<>();
        for (Utente membro : membri) model.addElement(membro);
        JList<Utente> selezione = new JList<>(model);
        selezione.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        selezione.setCellRenderer(rendererUtente());
        Set<String> assegnati = new HashSet<>(attivitaDAO.getMatricoleAssegnate(attivita.getIdAttivita()));
        for (int i = 0; i < model.size(); i++) {
            if (assegnati.contains(model.get(i).getMatricola())) selezione.addSelectionInterval(i, i);
        }
        JPanel assegnazioni = new JPanel(new BorderLayout(8, 8));
        assegnazioni.setOpaque(false);
        JLabel label = new JLabel("Responsabili della task");
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        assegnazioni.add(label, BorderLayout.NORTH);
        assegnazioni.add(new JScrollPane(selezione), BorderLayout.CENTER);
        LoginFrame.RoundedButton salva = new LoginFrame.RoundedButton("Salva responsabili", 10);
        salva.addActionListener(e -> {
            List<String> matricole = new ArrayList<>();
            for (Utente membro : selezione.getSelectedValuesList()) matricole.add(membro.getMatricola());
            if (matricole.isEmpty()) {
                mostraErrore("Seleziona almeno un responsabile della task.");
                return;
            }
            if (attivitaDAO.aggiornaAssegnatari(attivita, matricole)) {
                dialog.dispose();
                aggiornamento.run();
            } else mostraErrore("Non è stato possibile aggiornare i responsabili. Verifica che appartengano al progetto.");
        });
        JPanel azioni = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        azioni.setOpaque(false);
        azioni.add(salva);
        assegnazioni.add(azioni, BorderLayout.SOUTH);
        pannello.add(assegnazioni, BorderLayout.EAST);
        return pannello;
    }

    private JPanel creaEditorCodice() {
        JPanel pannello = new JPanel(new BorderLayout(0, 8));
        pannello.setBorder(new EmptyBorder(12, 12, 10, 12));
        pannello.setOpaque(false);
        JTextArea descrizioneIntervento = new JTextArea(2, 30);
        descrizioneIntervento.setLineWrap(true);
        descrizioneIntervento.setWrapStyleWord(true);
        descrizioneIntervento.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JPanel intestazione = new JPanel(new BorderLayout(0, 5));
        intestazione.setOpaque(false);
        JLabel etichettaDescrizione = new JLabel("Descrizione dell'intervento");
        etichettaDescrizione.setFont(new Font("Segoe UI", Font.BOLD, 12));
        intestazione.add(etichettaDescrizione, BorderLayout.NORTH);
        intestazione.add(new JScrollPane(descrizioneIntervento), BorderLayout.CENTER);
        codice = new JTextArea(attivita.getCodiceModulo() == null ? "" : attivita.getCodiceModulo());
        codice.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        codice.setTabSize(4);
        codice.setLineWrap(false);
        pannello.add(intestazione, BorderLayout.NORTH);
        pannello.add(new JScrollPane(codice), BorderLayout.CENTER);
        JLabel stato = new JLabel("Ogni salvataggio registra autore, data, intervento e codice completo.");
        stato.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        footer.add(stato, BorderLayout.CENTER);
        LoginFrame.RoundedButton salva = new LoginFrame.RoundedButton("Salva revisione", 10);
        salva.addActionListener(e -> {
            String sorgente = codice.getText();
            String descrizione = descrizioneIntervento.getText().trim();
            if (descrizione.isEmpty() || descrizione.length() > 500) {
                mostraErrore("Descrivi l'intervento con un testo compreso tra 1 e 500 caratteri.");
                return;
            }
            if (sorgente.trim().isEmpty()) {
                mostraErrore("Il codice sorgente non può essere vuoto.");
                return;
            }
            if (revisioneDAO.salvaCodiceConRevisione(attivita.getIdAttivita(), sorgente, descrizione, utente.getMatricola())) {
                attivita.setCodiceModulo(sorgente);
                promuoviStatoDopoContenuto();
                aggiornaRevisioni();
                aggiornamento.run();
            } else mostraErrore("Non è stato possibile salvare il codice e la revisione.");
        });
        JPanel azioni = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        azioni.setOpaque(false);
        azioni.add(salva);
        footer.add(azioni, BorderLayout.EAST);
        pannello.add(footer, BorderLayout.SOUTH);
        return pannello;
    }

    private JPanel creaRevisioni() {
        JPanel pannello = new JPanel(new BorderLayout(10, 0));
        pannello.setBorder(new EmptyBorder(12, 12, 10, 12));
        pannello.setOpaque(false);
        modelloRevisioni = new DefaultListModel<>();
        elencoRevisioni = new JList<>(modelloRevisioni);
        elencoRevisioni.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        elencoRevisioni.setCellRenderer(new DefaultListCellRenderer() {
            private final SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean selected, boolean focus) {
                super.getListCellRendererComponent(list, value, index, selected, focus);
                if (value instanceof Revisione) {
                    Revisione revisione = (Revisione) value;
                    setText("#" + revisione.getIdRevisione() + " · " + revisione.getNomeAutore() + " · " + formato.format(revisione.getDataOra()));
                }
                return this;
            }
        });
        testoRevisione = new JTextArea();
        testoRevisione.setEditable(false);
        testoRevisione.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        elencoRevisioni.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && elencoRevisioni.getSelectedValue() != null) {
                testoRevisione.setText(formatoDettaglioRevisione(elencoRevisioni.getSelectedValue()));
                testoRevisione.setCaretPosition(0);
            }
        });
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(elencoRevisioni), new JScrollPane(testoRevisione));
        split.setResizeWeight(0.30);
        pannello.add(split, BorderLayout.CENTER);
        aggiornaRevisioni();
        return pannello;
    }

    private void aggiornaRevisioni() {
        if (modelloRevisioni == null) return;
        modelloRevisioni.clear();
        for (Revisione revisione : revisioneDAO.getRevisioniPerAttivita(attivita.getIdAttivita())) modelloRevisioni.addElement(revisione);
        if (!modelloRevisioni.isEmpty()) {
            elencoRevisioni.setSelectedIndex(0);
        } else {
            testoRevisione.setText("Non sono ancora presenti revisioni per questa attività.");
        }
    }

    private String formatoDettaglioRevisione(Revisione revisione) {
        String data = new SimpleDateFormat("dd/MM/yyyy").format(revisione.getDataOra());
        String codiceSorgente = revisione.getCodiceSorgente();
        String descrizione = revisione.getNote();
        if (descrizione != null && descrizione.equals(codiceSorgente)) {
            descrizione = "Non registrata per questa revisione storica.";
        }
        return "Autore: " + revisione.getNomeAutore()
                + "\nData: " + data
                + "\n\nDescrizione dell'intervento\n" + descrizione
                + "\n\nCodice modificato\n" + (codiceSorgente == null ? "Codice non disponibile" : codiceSorgente);
    }

    private JPanel creaDocumento() {
        JPanel pannello = new JPanel(new BorderLayout(0, 12));
        pannello.setBorder(new EmptyBorder(18, 18, 18, 18));
        pannello.setOpaque(false);
        documentoCorrente = new JLabel(descrizioneDocumento(attivita.getUrlDocumento()));
        documentoCorrente.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        pannello.add(documentoCorrente, BorderLayout.NORTH);
        JTextArea info = new JTextArea("Il documento allegato viene salvato nel database insieme alla task, così i membri del progetto possono aprirlo.");
        info.setWrapStyleWord(true);
        info.setLineWrap(true);
        info.setEditable(false);
        info.setOpaque(false);
        pannello.add(info, BorderLayout.CENTER);
        JPanel azioni = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        azioni.setOpaque(false);
        LoginFrame.RoundedButton allega = new LoginFrame.RoundedButton("Allega documento", 10);
        allega.addActionListener(e -> allegaDocumento());
        LoginFrame.RoundedButton apri = new LoginFrame.RoundedButton("Apri documento", 10,
                new Color(236, 242, 249), new Color(222, 232, 244), new Color(0, 28, 99));
        apri.addActionListener(e -> apriDocumento());
        azioni.add(apri);
        azioni.add(allega);
        pannello.add(azioni, BorderLayout.SOUTH);
        return pannello;
    }

    private void allegaDocumento() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(dialog) != JFileChooser.APPROVE_OPTION) return;
        File file = chooser.getSelectedFile();
        try {
            String documento = DocumentoTask.codifica(file);
            if (attivitaDAO.aggiornaDocumento(attivita.getIdAttivita(), documento)) {
                attivita.setUrlDocumento(documento);
                documentoCorrente.setText(descrizioneDocumento(documento));
                promuoviStatoDopoContenuto();
                aggiornamento.run();
            } else mostraErrore("Non è stato possibile salvare il documento nella task.");
        } catch (IOException e) {
            mostraErrore("Non è stato possibile leggere il documento selezionato.");
        }
    }

    private void apriDocumento() {
        if (attivita.getUrlDocumento() == null || attivita.getUrlDocumento().isBlank()) {
            mostraErrore("Questa task non contiene ancora un documento.");
            return;
        }
        try {
            DocumentoTask.apri(attivita.getUrlDocumento());
        } catch (Exception e) {
            mostraErrore("Non è stato possibile aprire il documento. " + e.getMessage());
        }
    }

    private String descrizioneDocumento(String documento) {
        if (documento == null || documento.isBlank()) return "Nessun documento allegato";
        if (DocumentoTask.isDocumentoIncorporato(documento)) return "Documento salvato nel database";
        return DocumentoTask.nome(documento);
    }

    private JPanel creaCommenti() {
        JPanel pannello = new JPanel(new BorderLayout(0, 8));
        pannello.setBorder(new EmptyBorder(12, 12, 10, 12));
        pannello.setOpaque(false);
        DefaultListModel<String> commenti = new DefaultListModel<>();
        JList<String> elenco = new JList<>(commenti);
        elenco.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        elenco.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean selected, boolean focus) {
                super.getListCellRendererComponent(list, value, index, selected, focus);
                setBorder(new EmptyBorder(8, 8, 8, 8));
                return this;
            }
        });
        JTextArea nuovo = new JTextArea(3, 30);
        nuovo.setLineWrap(true);
        nuovo.setWrapStyleWord(true);
        JPanel footer = new JPanel(new BorderLayout(0, 6));
        footer.setOpaque(false);
        footer.add(new JScrollPane(nuovo), BorderLayout.CENTER);
        JLabel errore = new JLabel(" ");
        errore.setForeground(new Color(180, 45, 45));
        LoginFrame.RoundedButton invia = new LoginFrame.RoundedButton("Aggiungi commento", 10);
        invia.addActionListener(e -> {
            String testo = nuovo.getText().trim();
            if (testo.isEmpty() || testo.length() > 500) {
                errore.setText("Il commento deve contenere da 1 a 500 caratteri.");
                return;
            }
            Commento commento = new Commento(0, testo, new java.util.Date(), utente.getMatricola(), attivita.getIdAttivita());
            if (commentoDAO.creaCommento(commento)) {
                nuovo.setText("");
                errore.setText(" ");
                caricaCommenti(commenti);
                promuoviStatoDopoContenuto();
            } else errore.setText("Non è stato possibile salvare il commento.");
        });
        JPanel invio = new JPanel(new BorderLayout());
        invio.setOpaque(false);
        invio.add(errore, BorderLayout.CENTER);
        JPanel pulsanti = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pulsanti.setOpaque(false);
        pulsanti.add(invia);
        invio.add(pulsanti, BorderLayout.EAST);
        footer.add(invio, BorderLayout.SOUTH);
        pannello.add(new JScrollPane(elenco), BorderLayout.CENTER);
        pannello.add(footer, BorderLayout.SOUTH);
        caricaCommenti(commenti);
        return pannello;
    }

    private void caricaCommenti(DefaultListModel<String> modello) {
        modello.clear();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        for (Commento commento : commentoDAO.getCommentiPerAttivita(attivita.getIdAttivita())) {
            String testo = commento.getTesto().replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
            modello.addElement("<html><b>" + formato.format(commento.getDataOra()) + " · "
                    + commento.getMatricolaAutore() + "</b><br>" + testo + "</html>");
        }
    }

    private void promuoviStatoDopoContenuto() {
        if ("Iniziato".equals(attivita.getStato())
                && attivitaDAO.aggiornaStatoAttivita(attivita.getIdAttivita(), "In Corso")) {
            attivita.setStato("In Corso");
            aggiornamento.run();
        }
    }

    private ListCellRenderer<Utente> rendererUtente() {
        return (list, value, index, selected, focus) -> {
            JLabel label = new JLabel(value.getNome() + " " + value.getCognome() + " · " + value.getMatricola());
            label.setOpaque(true);
            label.setBackground(selected ? list.getSelectionBackground() : list.getBackground());
            label.setForeground(selected ? list.getSelectionForeground() : list.getForeground());
            label.setBorder(new EmptyBorder(4, 6, 4, 6));
            return label;
        };
    }

    private void mostraErrore(String messaggio) {
        CustomDialog errore = new CustomDialog(proprietario, "Attenzione");
        JPanel contenuto = errore.getContentPanel();
        contenuto.setLayout(new BorderLayout(0, 10));
        contenuto.add(new JLabel("<html><body style='width:320px'>" + messaggio + "</body></html>"), BorderLayout.CENTER);
        LoginFrame.RoundedButton chiudi = new LoginFrame.RoundedButton("Chiudi", 10);
        chiudi.addActionListener(e -> errore.dispose());
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.setOpaque(false);
        footer.add(chiudi);
        contenuto.add(footer, BorderLayout.SOUTH);
        errore.pack();
        errore.setLocationRelativeTo(proprietario);
        errore.setVisible(true);
    }
}
