package UninaTaskBoard_GUI;

import UninaTaskBoard_DAO.NotificaDAO;
import UninaTaskBoard_Model.Notifica;
import UninaTaskBoard_Model.Utente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.text.SimpleDateFormat;

public class NotifichePanel extends JPanel {
    private final Color primary = new Color(0, 28, 99);
    private final Utente utente;
    private final MainFrame mainFrame;
    private final NotificaDAO notificaDAO = new NotificaDAO();
    private final JPanel elenco = new JPanel();

    public NotifichePanel(Utente utente, MainFrame mainFrame) {
        this.utente = utente;
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(245, 247, 250));
        setBorder(new EmptyBorder(25, 25, 25, 25));
        JLabel titolo = new JLabel("NOTIFICHE");
        titolo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titolo.setForeground(primary);
        add(titolo, BorderLayout.NORTH);
        elenco.setOpaque(false);
        elenco.setLayout(new BoxLayout(elenco, BoxLayout.Y_AXIS));
        JScrollPane scroll = new JScrollPane(elenco);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        add(scroll, BorderLayout.CENTER);
        aggiornaElenco();
    }

    public void caricaNotifiche() {
        notificaDAO.segnaTutteComeLette(utente.getMatricola());
        aggiornaElenco();
    }

    private void aggiornaElenco() {
        elenco.removeAll();
        java.util.List<Notifica> notifiche = notificaDAO.getNotificheUtente(utente.getMatricola());
        if (notifiche.isEmpty()) {
            JLabel vuoto = new JLabel("Non hai notifiche al momento.");
            vuoto.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            vuoto.setForeground(new Color(90, 98, 108));
            vuoto.setBorder(new EmptyBorder(8, 2, 8, 2));
            vuoto.setAlignmentX(Component.LEFT_ALIGNMENT);
            elenco.add(vuoto);
        } else {
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy · HH:mm");
            for (Notifica notifica : notifiche) {
                LoginFrame.RoundedPanel card = new LoginFrame.RoundedPanel(14, Color.WHITE);
                card.setLayout(new BorderLayout(0, 7));
                card.setBorder(new EmptyBorder(14, 16, 14, 16));
                card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 150));
                card.setAlignmentX(Component.LEFT_ALIGNMENT);
                JLabel data = new JLabel(notifica.getDataOra() == null ? "" : formato.format(notifica.getDataOra()));
                data.setFont(new Font("Segoe UI", Font.BOLD, 11));
                data.setForeground(primary);
                JTextArea messaggio = new JTextArea(notifica.getMessaggio());
                messaggio.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                messaggio.setLineWrap(true);
                messaggio.setWrapStyleWord(true);
                messaggio.setEditable(false);
                messaggio.setOpaque(false);
                card.add(data, BorderLayout.NORTH);
                card.add(messaggio, BorderLayout.CENTER);
                elenco.add(card);
                elenco.add(Box.createRigidArea(new Dimension(0, 10)));
            }
        }
        elenco.revalidate();
        elenco.repaint();
    }
}
