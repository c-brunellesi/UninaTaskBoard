package UninaTaskBoard_GUI;

import UninaTaskBoard_DAO.ProgettoDAO;
import UninaTaskBoard_DAO.UtenteDAO;
import UninaTaskBoard_DAO.InvitoDAO;
import UninaTaskBoard_Model.Invito;
import UninaTaskBoard_Model.PartecipanteProgetto;
import UninaTaskBoard_Model.Progetto;
import UninaTaskBoard_Model.Utente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.geom.Path2D;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class ProgettiPanel extends JPanel {

    private Utente utente;
    private MainFrame mainFrame;
    private ProgettoDAO progettoDAO;
    private UtenteDAO utenteDAO;
    private InvitoDAO invitoDAO;

    private JPanel pnlGridProgetti;

    private final Color COLOR_PRIMARY = new Color(0, 28, 99);
    private final Color COLOR_BG = new Color(245, 247, 250);

    public ProgettiPanel(Utente utente, MainFrame mainFrame) {
        this.utente = utente;
        this.mainFrame = mainFrame;
        this.progettoDAO = new ProgettoDAO();
        this.utenteDAO = new UtenteDAO();
        this.invitoDAO = new InvitoDAO();

        setLayout(new BorderLayout(15, 15));
        setBackground(COLOR_BG);
        setBorder(new EmptyBorder(25, 25, 25, 25));

        JPanel pnlHeader = new JPanel(new BorderLayout());
        pnlHeader.setOpaque(false);

        JLabel lblTitle = new JLabel("TASK BOARD - I MIEI PROGETTI");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(COLOR_PRIMARY);

        LoginFrame.RoundedButton btnCrea = new LoginFrame.RoundedButton("+ Crea Nuovo Progetto", 10);
        btnCrea.setPreferredSize(new Dimension(200, 36));
        btnCrea.addActionListener(e -> mostraDialogCreaProgetto());

        pnlHeader.add(lblTitle, BorderLayout.WEST);
        pnlHeader.add(btnCrea, BorderLayout.EAST);

        pnlGridProgetti = new JPanel(new GridLayout(0, 3, 15, 15));
        pnlGridProgetti.setOpaque(false);

        JScrollPane scroll = new JScrollPane(pnlGridProgetti);
        scroll.setBorder(null);
        scroll.getViewport().setOpaque(false);
        scroll.setOpaque(false);

        add(pnlHeader, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        caricaProgetti();
    }

    public void caricaProgetti() {
        pnlGridProgetti.removeAll();
        List<Progetto> lista = progettoDAO.getProgettiPerUtente(utente.getMatricola());

        for (Progetto p : lista) {
            pnlGridProgetti.add(creaCardProgetto(p));
        }

        pnlGridProgetti.revalidate();
        pnlGridProgetti.repaint();
    }

    private JPanel creaCardProgetto(Progetto p) {
        LoginFrame.RoundedPanel card = new LoginFrame.RoundedPanel(15, Color.WHITE);
        card.setLayout(new BorderLayout(10, 10));
        card.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblNome = new JLabel(p.getNome());
        lblNome.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblNome.setForeground(COLOR_PRIMARY);

        JPanel pnlTitolo = new JPanel(new BorderLayout(8, 0));
        pnlTitolo.setOpaque(false);
        pnlTitolo.add(lblNome, BorderLayout.CENTER);
        boolean dirigente = p.getMatricolaDirigente().equals(utente.getMatricola());
        JPanel azioniTitolo = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        azioniTitolo.setOpaque(false);
        LoginFrame.RoundedButton btnPartecipanti = new LoginFrame.RoundedButton("", 9,
                new Color(236, 242, 249), new Color(222, 232, 244), COLOR_PRIMARY);
        btnPartecipanti.setIcon(new UserIcon(COLOR_PRIMARY));
        btnPartecipanti.setPreferredSize(new Dimension(36, 30));
        btnPartecipanti.setToolTipText("Visualizza partecipanti");
        btnPartecipanti.getAccessibleContext().setAccessibleName("Visualizza partecipanti");
        btnPartecipanti.addActionListener(e -> mostraDialogPartecipantiProgetto(p));
        azioniTitolo.add(btnPartecipanti);
        if (dirigente) {
            LoginFrame.RoundedButton btnRinomina = new LoginFrame.RoundedButton("", 9,
                    new Color(236, 242, 249), new Color(222, 232, 244), COLOR_PRIMARY);
            btnRinomina.setIcon(new PencilIcon(COLOR_PRIMARY));
            btnRinomina.setPreferredSize(new Dimension(36, 30));
            btnRinomina.setToolTipText("Rinomina progetto");
            btnRinomina.getAccessibleContext().setAccessibleName("Rinomina progetto");
            btnRinomina.addActionListener(e -> mostraDialogRinominaProgetto(p));
            azioniTitolo.add(btnRinomina);
        }
        pnlTitolo.add(azioniTitolo, BorderLayout.EAST);

        JPanel pnlInfo = new JPanel();
        pnlInfo.setLayout(new BoxLayout(pnlInfo, BoxLayout.Y_AXIS));
        pnlInfo.setOpaque(false);
        if ("Esame".equals(p.getTipoProgetto()) && p.getMateria() != null && !p.getMateria().isBlank()) {
            pnlInfo.add(creaEtichettaInfo("Materia: " + p.getMateria()));
        } else if ("Sviluppo".equals(p.getTipoProgetto()) && p.getLinguaggio() != null && !p.getLinguaggio().isBlank()) {
            pnlInfo.add(creaEtichettaInfo("Linguaggio: " + p.getLinguaggio()));
        }
        pnlInfo.add(creaEtichettaInfo("Tipo: " + p.getTipoProgetto()));
        pnlInfo.add(creaEtichettaInfo("Ruolo: " + (dirigente ? "Dirigente" : "Partecipante")));

        JPanel pnlActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        pnlActions.setOpaque(false);

        LoginFrame.RoundedButton btnAttivita = new LoginFrame.RoundedButton("Apri attività", 9,
                new Color(236, 242, 249), new Color(222, 232, 244), COLOR_PRIMARY);
        btnAttivita.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        btnAttivita.setPreferredSize(new Dimension(120, 32));
        btnAttivita.addActionListener(e -> mainFrame.mostraAttivitaProgetto(p.getIdProg()));
        pnlActions.add(btnAttivita);

        if (dirigente) {
            LoginFrame.RoundedButton btnInvita = new LoginFrame.RoundedButton("Invita Utente", 9);
            btnInvita.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            btnInvita.setPreferredSize(new Dimension(130, 32));
            btnInvita.addActionListener(e -> mostraDialogInvitaUtente(p));
            pnlActions.add(btnInvita);
        }

        card.add(pnlTitolo, BorderLayout.NORTH);
        card.add(pnlInfo, BorderLayout.CENTER);
        card.add(pnlActions, BorderLayout.SOUTH);

        return card;
    }

    private void mostraDialogPartecipantiProgetto(Progetto progetto) {
        List<PartecipanteProgetto> partecipanti = progettoDAO.getPartecipantiProgetto(progetto.getIdProg());
        String[] colonne = {"Nome", "Cognome", "Matricola", "Nel progetto dal", "Ruolo"};
        javax.swing.table.DefaultTableModel modello = new javax.swing.table.DefaultTableModel(colonne, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        for (PartecipanteProgetto partecipante : partecipanti) {
            modello.addRow(new Object[]{partecipante.getNome(), partecipante.getCognome(),
                    partecipante.getMatricola(), partecipante.getDataPartecipazione() == null
                    ? "—" : formato.format(partecipante.getDataPartecipazione()),
                    partecipante.isDirigente() ? "Dirigente" : "Partecipante"});
        }

        JTable tabella = new JTable(modello);
        tabella.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabella.setRowHeight(34);
        tabella.setFillsViewportHeight(true);
        tabella.setShowVerticalLines(false);
        tabella.setGridColor(new Color(230, 235, 242));
        tabella.setSelectionBackground(new Color(222, 235, 250));
        tabella.setSelectionForeground(COLOR_PRIMARY);
        tabella.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabella.getTableHeader().setForeground(COLOR_PRIMARY);
        tabella.getTableHeader().setBackground(new Color(236, 242, 249));
        tabella.getTableHeader().setReorderingAllowed(false);

        CustomDialog dialog = new CustomDialog((Frame) SwingUtilities.getWindowAncestor(this),
                "Partecipanti · " + progetto.getNome());
        JPanel content = dialog.getContentPanel();
        content.setLayout(new BorderLayout(0, 10));
        JLabel riepilogo = new JLabel(partecipanti.size() + (partecipanti.size() == 1
                ? " persona nel progetto" : " persone nel progetto"));
        riepilogo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        riepilogo.setForeground(new Color(90, 98, 108));
        content.add(riepilogo, BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(tabella);
        scroll.setPreferredSize(new Dimension(680, Math.min(280, Math.max(100, partecipanti.size() * 35 + 35))));
        scroll.getViewport().setBackground(Color.WHITE);
        content.add(scroll, BorderLayout.CENTER);
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        footer.setOpaque(false);
        LoginFrame.RoundedButton chiudi = new LoginFrame.RoundedButton("Chiudi", 10,
                new Color(236, 242, 249), new Color(222, 232, 244), COLOR_PRIMARY);
        chiudi.addActionListener(e -> dialog.dispose());
        footer.add(chiudi);
        content.add(footer, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private JLabel creaEtichettaInfo(String testo) {
        JLabel label = new JLabel(testo);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        label.setForeground(new Color(70, 78, 88));
        label.setBorder(new EmptyBorder(2, 0, 2, 0));
        return label;
    }

    private void mostraDialogRinominaProgetto(Progetto progetto) {
        JTextField txtNome = new JTextField(progetto.getNome());
        CustomDialog dialog = new CustomDialog((Frame) SwingUtilities.getWindowAncestor(this), "Rinomina progetto");
        JPanel content = dialog.getContentPanel();
        content.setLayout(new BorderLayout(0, 8));
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);
        aggiungiCampo(form, gbc, "Nuovo nome del progetto", txtNome);
        JLabel lblErrore = new JLabel(" ");
        lblErrore.setForeground(new Color(180, 45, 45));
        lblErrore.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        footer.add(lblErrore, BorderLayout.NORTH);
        footer.add(creaAzioniDialog(dialog, "Salva", () -> {
            String nome = txtNome.getText().trim();
            if (nome.isEmpty() || nome.length() > 50) {
                lblErrore.setText("Inserisci un nome compreso tra 1 e 50 caratteri.");
                return;
            }
            if (nome.equals(progetto.getNome())) {
                dialog.dispose();
                return;
            }
            if (progettoDAO.rinominaProgetto(progetto.getIdProg(), utente.getMatricola(), nome)) {
                progetto.setNome(nome);
                dialog.dispose();
                caricaProgetti();
            } else {
                lblErrore.setText("Non è stato possibile rinominare il progetto.");
            }
        }), BorderLayout.SOUTH);
        content.add(form, BorderLayout.CENTER);
        content.add(footer, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        SwingUtilities.invokeLater(() -> {
            txtNome.requestFocusInWindow();
            txtNome.selectAll();
        });
        dialog.setVisible(true);
    }

    private void mostraDialogCreaProgetto() {
        JTextField txtNome = new JTextField();
        JTextField txtMateria = new JTextField();
        JTextField txtLinguaggio = new JTextField();
        DatePickerField txtScadenza = new DatePickerField();
        JComboBox<String> cmbTipo = new JComboBox<>(new String[]{"Gruppo", "Esame", "Sviluppo"});
        CustomDialog dialog = new CustomDialog((Frame) SwingUtilities.getWindowAncestor(this), "Crea Nuovo Progetto");
        JPanel content = dialog.getContentPanel();
        content.setLayout(new BorderLayout(0, 8));
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);
        aggiungiCampo(form, gbc, "Nome progetto", txtNome);
        aggiungiCampo(form, gbc, "Tipo progetto", cmbTipo);
        JPanel campoDinamico = new JPanel(new BorderLayout(0, 5));
        campoDinamico.setOpaque(false);
        JLabel lblDinamica = new JLabel();
        lblDinamica.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblDinamica.setForeground(COLOR_PRIMARY);
        campoDinamico.add(lblDinamica, BorderLayout.NORTH);
        campoDinamico.add(txtMateria, BorderLayout.CENTER);
        form.add(campoDinamico, gbc);
        gbc.gridy++;
        aggiungiCampo(form, gbc, "Scadenza progetto (facoltativa)", txtScadenza);
        cmbTipo.addActionListener(e -> {
            String tipo = (String) cmbTipo.getSelectedItem();
            campoDinamico.remove(txtMateria);
            campoDinamico.remove(txtLinguaggio);
            if ("Esame".equals(tipo)) {
                lblDinamica.setText("Materia");
                campoDinamico.add(txtMateria, BorderLayout.CENTER);
            } else if ("Sviluppo".equals(tipo)) {
                lblDinamica.setText("Linguaggio");
                campoDinamico.add(txtLinguaggio, BorderLayout.CENTER);
            } else {
                lblDinamica.setText("Nessun campo aggiuntivo richiesto");
            }
            campoDinamico.revalidate(); campoDinamico.repaint();
            dialog.pack(); dialog.setLocationRelativeTo(this);
        });
        cmbTipo.setSelectedIndex(0);
        JLabel lblErrore = new JLabel(" ");
        lblErrore.setForeground(new Color(180, 45, 45));
        lblErrore.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        content.add(form, BorderLayout.CENTER);
        JPanel actions = creaAzioniDialog(dialog, "Crea", () -> {
            String nome = txtNome.getText().trim();
            String tipo = (String) cmbTipo.getSelectedItem();
            String materia = "Esame".equals(tipo) ? valoreOPulito(txtMateria) : null;
            String linguaggio = "Sviluppo".equals(tipo) ? valoreOPulito(txtLinguaggio) : null;
            java.util.Date scadenza = null;
            if (!txtScadenza.getText().trim().isEmpty()) {
                try {
                    LocalDate data = LocalDate.parse(txtScadenza.getText().trim(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                    scadenza = java.sql.Date.valueOf(data);
                    if (data.isBefore(LocalDate.now())) {
                        lblErrore.setText("La scadenza non può essere precedente alla data di inizio."); return;
                    }
                } catch (DateTimeParseException ex) {
                    lblErrore.setText("Inserisci la scadenza nel formato gg/mm/aaaa."); return;
                }
            }
            if (nome.isEmpty() || nome.length() > 50 || ("Esame".equals(tipo) && (materia == null || materia.length() > 50)) || ("Sviluppo".equals(tipo) && (linguaggio == null || linguaggio.length() > 50))) {
                lblErrore.setText("Inserisci un nome (massimo 50 caratteri) e compila il campo richiesto dal tipo."); return;
            }
            Progetto p = new Progetto(0, nome, new java.util.Date(), scadenza, tipo, materia, linguaggio, utente.getMatricola());
            if (progettoDAO.creaProgetto(p)) { dialog.dispose(); caricaProgetti(); }
            else lblErrore.setText("Errore nella creazione del progetto.");
        });
        JPanel footer = new JPanel(new BorderLayout()); footer.setOpaque(false);
        footer.add(lblErrore, BorderLayout.NORTH); footer.add(actions, BorderLayout.SOUTH);
        content.add(footer, BorderLayout.SOUTH);
        dialog.pack(); dialog.setLocationRelativeTo(this); dialog.setVisible(true);
    }

    private void aggiungiCampo(JPanel form, GridBagConstraints gbc, String titolo, JComponent campo) {
        JPanel riga = new JPanel(new BorderLayout(0, 5)); riga.setOpaque(false);
        JLabel label = new JLabel(titolo); label.setFont(new Font("Segoe UI", Font.PLAIN, 12)); label.setForeground(COLOR_PRIMARY);
        campo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        riga.add(label, BorderLayout.NORTH); riga.add(campo, BorderLayout.CENTER); form.add(riga, gbc); gbc.gridy++;
    }

    private String valoreOPulito(JTextField campo) { String valore = campo.getText().trim(); return valore.isEmpty() ? null : valore; }

    private static class PencilIcon implements Icon {
        private final Color color;
        private PencilIcon(Color color) { this.color = color; }
        public int getIconWidth() { return 16; }
        public int getIconHeight() { return 16; }
        public void paintIcon(Component component, Graphics graphics, int x, int y) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.translate(x, y);
            g.setColor(color);
            Path2D punta = new Path2D.Double();
            punta.moveTo(2, 12); punta.lineTo(3.5, 8.8); punta.lineTo(11.8, 0.8);
            punta.lineTo(15.2, 4.2); punta.lineTo(7.1, 12.4); punta.lineTo(3.4, 13.4); punta.closePath();
            g.fill(punta);
            g.setStroke(new BasicStroke(1.3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.drawLine(3, 14, 13, 14);
            g.dispose();
        }
    }

    private static class UserIcon implements Icon {
        private final Color color;
        private UserIcon(Color color) { this.color = color; }
        public int getIconWidth() { return 18; }
        public int getIconHeight() { return 18; }
        public void paintIcon(Component component, Graphics graphics, int x, int y) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(color);
            g.fillOval(x + 6, y + 1, 7, 7);
            g.fillRoundRect(x + 3, y + 9, 13, 8, 6, 6);
            g.dispose();
        }
    }

    private JPanel creaAzioniDialog(CustomDialog dialog, String testo, Runnable azione) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4)); panel.setOpaque(false);
        LoginFrame.RoundedButton annulla = new LoginFrame.RoundedButton("Annulla", 10,
                new Color(236, 242, 249), new Color(222, 232, 244), COLOR_PRIMARY);
        annulla.addActionListener(e -> dialog.dispose());
        LoginFrame.RoundedButton conferma = new LoginFrame.RoundedButton(testo, 10);
        conferma.addActionListener(e -> azione.run()); panel.add(annulla); panel.add(conferma); return panel;
    }


    private void mostraDialogInvitaUtente(Progetto p) {
        JTextField txtRicerca = new JTextField();
        txtRicerca.setToolTipText("Cerca per nome, cognome o matricola");
        txtRicerca.setPreferredSize(new Dimension(360, 34));
        DefaultListModel<Utente> modelloSuggerimenti = new DefaultListModel<>();
        JList<Utente> listaSuggerimenti = new JList<>(modelloSuggerimenti);
        listaSuggerimenti.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaSuggerimenti.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        listaSuggerimenti.setFixedCellHeight(42);
        listaSuggerimenti.setCellRenderer((list, value, index, selected, focused) -> {
            JPanel riga = new JPanel(new BorderLayout(8, 0));
            riga.setOpaque(true);
            riga.setBackground(selected ? new Color(222, 235, 250) : Color.WHITE);
            riga.setBorder(new EmptyBorder(5, 10, 5, 10));
            JLabel nome = new JLabel(value.getNome() + " " + value.getCognome());
            nome.setFont(new Font("Segoe UI", Font.BOLD, 13));
            nome.setForeground(COLOR_PRIMARY);
            JLabel matricola = new JLabel(value.getMatricola());
            matricola.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            matricola.setForeground(new Color(95, 105, 118));
            riga.add(nome, BorderLayout.CENTER);
            riga.add(matricola, BorderLayout.EAST);
            return riga;
        });
        JPopupMenu popupSuggerimenti = new JPopupMenu();
        popupSuggerimenti.setBorder(BorderFactory.createLineBorder(new Color(205, 215, 228)));
        JScrollPane scrollSuggerimenti = new JScrollPane(listaSuggerimenti);
        scrollSuggerimenti.setBorder(null);
        scrollSuggerimenti.setPreferredSize(new Dimension(360, 210));
        popupSuggerimenti.add(scrollSuggerimenti);
        JLabel lblSuggerimento = new JLabel("Digita almeno 2 caratteri per cercare gli utenti registrati.");
        lblSuggerimento.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblSuggerimento.setForeground(new Color(100, 108, 118));
        Utente[] utenteSelezionato = {null};
        boolean[] selezioneDaMenu = {false};
        int[] versioneRicerca = {0};
        javax.swing.Timer timerRicerca = new javax.swing.Timer(250, e -> {
            String testo = txtRicerca.getText().trim();
            int versione = ++versioneRicerca[0];
            if (testo.length() < 2) {
                modelloSuggerimenti.clear();
                popupSuggerimenti.setVisible(false);
                lblSuggerimento.setText("Digita almeno 2 caratteri per cercare gli utenti registrati.");
                return;
            }
            lblSuggerimento.setText("Ricerca in corso...");
            new SwingWorker<List<Utente>, Void>() {
                protected List<Utente> doInBackground() {
                    return utenteDAO.cercaUtentiPerInvito(testo, p.getIdProg(), utente.getMatricola());
                }
                protected void done() {
                    if (versione != versioneRicerca[0] || !testo.equals(txtRicerca.getText().trim())) return;
                    try {
                        List<Utente> risultati = get();
                        modelloSuggerimenti.clear();
                        for (Utente risultato : risultati) modelloSuggerimenti.addElement(risultato);
                        if (risultati.isEmpty()) {
                            popupSuggerimenti.setVisible(false);
                            lblSuggerimento.setText("Nessun utente registrato trovato.");
                        } else {
                            listaSuggerimenti.setSelectedIndex(0);
                            lblSuggerimento.setText("Seleziona una persona dall'elenco.");
                            if (txtRicerca.isFocusOwner()) popupSuggerimenti.show(txtRicerca, 0, txtRicerca.getHeight());
                        }
                    } catch (Exception ex) {
                        popupSuggerimenti.setVisible(false);
                        lblSuggerimento.setText("Ricerca non disponibile. Riprova.");
                    }
                }
            }.execute();
        });
        txtRicerca.getDocument().addDocumentListener(new DocumentListener() {
            private void aggiorna() {
                if (selezioneDaMenu[0]) return;
                utenteSelezionato[0] = null;
                timerRicerca.restart();
            }
            public void insertUpdate(DocumentEvent e) { aggiorna(); }
            public void removeUpdate(DocumentEvent e) { aggiorna(); }
            public void changedUpdate(DocumentEvent e) { aggiorna(); }
        });
        Runnable selezionaSuggerimento = () -> {
            Utente selezionato = listaSuggerimenti.getSelectedValue();
            if (selezionato == null) return;
            timerRicerca.stop();
            versioneRicerca[0]++;
            utenteSelezionato[0] = selezionato;
            selezioneDaMenu[0] = true;
            txtRicerca.setText(selezionato.getNome() + " " + selezionato.getCognome() + " · " + selezionato.getMatricola());
            selezioneDaMenu[0] = false;
            popupSuggerimenti.setVisible(false);
            lblSuggerimento.setText("Utente selezionato: " + selezionato.getMatricola());
        };
        listaSuggerimenti.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 1) selezionaSuggerimento.run();
            }
        });
        txtRicerca.getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "suggerimentoSuccessivo");
        txtRicerca.getActionMap().put("suggerimentoSuccessivo", new AbstractAction() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                if (!modelloSuggerimenti.isEmpty()) {
                    listaSuggerimenti.setSelectedIndex(Math.min(listaSuggerimenti.getSelectedIndex() + 1, modelloSuggerimenti.size() - 1));
                    if (!popupSuggerimenti.isVisible()) popupSuggerimenti.show(txtRicerca, 0, txtRicerca.getHeight());
                }
            }
        });
        txtRicerca.getInputMap().put(KeyStroke.getKeyStroke("UP"), "suggerimentoPrecedente");
        txtRicerca.getActionMap().put("suggerimentoPrecedente", new AbstractAction() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                if (!modelloSuggerimenti.isEmpty()) listaSuggerimenti.setSelectedIndex(Math.max(listaSuggerimenti.getSelectedIndex() - 1, 0));
            }
        });
        txtRicerca.getInputMap().put(KeyStroke.getKeyStroke("ENTER"), "scegliSuggerimento");
        txtRicerca.getActionMap().put("scegliSuggerimento", new AbstractAction() {
            public void actionPerformed(java.awt.event.ActionEvent e) { selezionaSuggerimento.run(); }
        });
        txtRicerca.getInputMap().put(KeyStroke.getKeyStroke("ESCAPE"), "chiudiSuggerimenti");
        txtRicerca.getActionMap().put("chiudiSuggerimenti", new AbstractAction() {
            public void actionPerformed(java.awt.event.ActionEvent e) { popupSuggerimenti.setVisible(false); }
        });
        CustomDialog dialog = new CustomDialog((Frame) SwingUtilities.getWindowAncestor(this), "Invita utente al progetto");
        JPanel content = dialog.getContentPanel();
        content.setLayout(new BorderLayout(0, 10));
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);
        aggiungiCampo(form, gbc, "Cerca per nome, cognome o matricola", txtRicerca);
        gbc.gridy++;
        form.add(lblSuggerimento, gbc);
        JLabel lblErrore = new JLabel(" ");
        lblErrore.setForeground(new Color(180, 45, 45));
        lblErrore.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4));
        actions.setOpaque(false);
        LoginFrame.RoundedButton annulla = new LoginFrame.RoundedButton("Annulla", 10,
                new Color(236, 242, 249), new Color(222, 232, 244), COLOR_PRIMARY);
        annulla.addActionListener(e -> dialog.dispose());
        LoginFrame.RoundedButton invia = new LoginFrame.RoundedButton("Invia invito", 10);
        invia.addActionListener(e -> {
            Utente destinatario = utenteSelezionato[0];
            if (destinatario == null) {
                lblErrore.setText("Cerca e seleziona una persona dall'elenco.");
                return;
            }
            String destMatricola = destinatario.getMatricola();
            if (destMatricola.equals(utente.getMatricola())) {
                lblErrore.setText("Non puoi invitare te stesso.");
                return;
            }
            if (progettoDAO.getMatricolePartecipanti(p.getIdProg()).contains(destMatricola)
                    || destMatricola.equals(p.getMatricolaDirigente())) {
                lblErrore.setText("L'utente partecipa già a questo progetto.");
                return;
            }
            if (invitoDAO.esisteInvitoPendente(destMatricola, p.getIdProg())) {
                dialog.dispose();
                mostraMessaggioInvito("Per " + destinatario.getNome() + " " + destinatario.getCognome()
                        + " esiste già un invito in attesa per questo progetto. Non serve inviarlo di nuovo: "
                        + "l'utente può accedere con il proprio account e accettarlo dalla sezione Inviti.");
                return;
            }
            Invito invito = new Invito(0, utente.getMatricola(), destMatricola, p.getIdProg(), "In Attesa", null);
            if (invitoDAO.inviaInvito(invito)) {
                dialog.dispose();
                mostraMessaggioInvito("Invito inviato. L'utente potrà accettarlo o rifiutarlo dalla sezione Inviti.");
            } else {
                lblErrore.setText("Non è stato possibile inviare l'invito. Verifica i dati e riprova.");
            }
        });
        actions.add(annulla);
        actions.add(invia);
        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        footer.add(lblErrore, BorderLayout.NORTH);
        footer.add(actions, BorderLayout.SOUTH);
        content.add(form, BorderLayout.CENTER);
        content.add(footer, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void mostraMessaggioInvito(String messaggio) {
        CustomDialog dialog = new CustomDialog((Frame) SwingUtilities.getWindowAncestor(this), "Invito al progetto");
        JPanel content = dialog.getContentPanel();
        content.setLayout(new BorderLayout(0, 12));
        JLabel label = new JLabel(messaggio);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        content.add(label, BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);
        LoginFrame.RoundedButton close = new LoginFrame.RoundedButton("Chiudi", 10);
        close.addActionListener(e -> dialog.dispose());
        actions.add(close);
        content.add(actions, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
}
