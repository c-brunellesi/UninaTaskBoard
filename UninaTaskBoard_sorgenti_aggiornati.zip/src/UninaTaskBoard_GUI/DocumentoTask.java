package UninaTaskBoard_GUI;

import java.awt.Desktop;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URLConnection;
import java.nio.file.Files;
import java.util.Base64;

public final class DocumentoTask {
    private static final String PREFIX = "UTBDOC1:";

    private DocumentoTask() {
    }

    public static String codifica(File file) throws IOException {
        byte[] contenuto = Files.readAllBytes(file.toPath());
        String nome = Base64.getUrlEncoder().withoutPadding().encodeToString(file.getName().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String tipo = URLConnection.guessContentTypeFromStream(new ByteArrayInputStream(contenuto));
        if (tipo == null) tipo = "application/octet-stream";
        String mime = Base64.getUrlEncoder().withoutPadding().encodeToString(tipo.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String dati = Base64.getEncoder().encodeToString(contenuto);
        return PREFIX + nome + ":" + mime + ":" + dati;
    }

    public static boolean isDocumentoIncorporato(String valore) {
        return valore != null && valore.startsWith(PREFIX);
    }

    public static String nome(String valore) {
        if (!isDocumentoIncorporato(valore)) return valore;
        String[] parti = valore.substring(PREFIX.length()).split(":", 3);
        if (parti.length != 3) return "Documento incorporato";
        try {
            return new String(Base64.getUrlDecoder().decode(parti[0]), java.nio.charset.StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return "Documento incorporato";
        }
    }

    public static void apri(String valore) throws Exception {
        if (!Desktop.isDesktopSupported()) throw new IOException("Apertura documenti non supportata su questo computer.");
        if (isDocumentoIncorporato(valore)) {
            String[] parti = valore.substring(PREFIX.length()).split(":", 3);
            if (parti.length != 3) throw new IOException("Documento non valido.");
            String nome = new String(Base64.getUrlDecoder().decode(parti[0]), java.nio.charset.StandardCharsets.UTF_8);
            byte[] dati = Base64.getDecoder().decode(parti[2]);
            String suffisso = nome.lastIndexOf('.') >= 0 ? nome.substring(nome.lastIndexOf('.')) : ".tmp";
            File temporaneo = File.createTempFile("unina-task-", suffisso);
            temporaneo.deleteOnExit();
            Files.write(temporaneo.toPath(), dati);
            Desktop.getDesktop().open(temporaneo);
            return;
        }
        if (valore.startsWith("http://") || valore.startsWith("https://")) {
            Desktop.getDesktop().browse(URI.create(valore));
            return;
        }
        if (valore.startsWith("file:")) {
            Desktop.getDesktop().open(new File(URI.create(valore)));
            return;
        }
        Desktop.getDesktop().open(new File(valore));
    }
}
