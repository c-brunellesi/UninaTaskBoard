package UninaTaskBoard_GUI;

import javax.swing.BorderFactory;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.Font;

public final class AppTheme {
    public static final Color PRIMARY = new Color(0, 28, 99);
    public static final Color BACKGROUND = new Color(245, 247, 250);
    public static final Color SURFACE = Color.WHITE;
    public static final Color FIELD = new Color(248, 250, 253);
    public static final Color BORDER = new Color(214, 223, 234);
    public static final Color TEXT = new Color(35, 45, 60);
    public static final Color MUTED = new Color(102, 112, 128);
    public static final Color HIGHLIGHT = new Color(222, 235, 250);

    private AppTheme() {
    }

    public static void apply() {
        Font body = new Font("Segoe UI", Font.PLAIN, 13);
        Font bold = new Font("Segoe UI", Font.BOLD, 13);
        UIManager.put("Label.font", body);
        UIManager.put("Label.foreground", TEXT);
        UIManager.put("Panel.background", BACKGROUND);
        UIManager.put("Button.font", bold);
        UIManager.put("ToggleButton.font", bold);
        UIManager.put("TextField.font", body);
        UIManager.put("PasswordField.font", body);
        UIManager.put("TextArea.font", body);
        UIManager.put("ComboBox.font", body);
        UIManager.put("ComboBox.background", SURFACE);
        UIManager.put("ComboBox.selectionBackground", HIGHLIGHT);
        UIManager.put("ComboBox.selectionForeground", PRIMARY);
        UIManager.put("ComboBox.border", BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1, true),
                BorderFactory.createEmptyBorder(2, 5, 2, 5)));
        UIManager.put("TextField.background", FIELD);
        UIManager.put("PasswordField.background", FIELD);
        UIManager.put("TextArea.background", FIELD);
        UIManager.put("TextField.foreground", TEXT);
        UIManager.put("PasswordField.foreground", TEXT);
        UIManager.put("TextArea.foreground", TEXT);
        UIManager.put("Table.font", body);
        UIManager.put("Table.foreground", TEXT);
        UIManager.put("Table.background", SURFACE);
        UIManager.put("Table.selectionBackground", HIGHLIGHT);
        UIManager.put("Table.selectionForeground", PRIMARY);
        UIManager.put("Table.gridColor", BORDER);
        UIManager.put("TableHeader.font", bold);
        UIManager.put("TableHeader.background", BACKGROUND);
        UIManager.put("TableHeader.foreground", PRIMARY);
        UIManager.put("List.font", body);
        UIManager.put("List.foreground", TEXT);
        UIManager.put("List.background", SURFACE);
        UIManager.put("List.selectionBackground", HIGHLIGHT);
        UIManager.put("List.selectionForeground", PRIMARY);
        UIManager.put("ScrollBar.thumb", new Color(188, 201, 218));
        UIManager.put("ScrollBar.track", BACKGROUND);
        UIManager.put("ToolTip.background", PRIMARY);
        UIManager.put("ToolTip.foreground", SURFACE);
        UIManager.put("ToolTip.border", BorderFactory.createEmptyBorder(5, 8, 5, 8));
        UIManager.put("ScrollBar.width", 10);
    }
}
