package UninaTaskBoard_GUI;

import UninaTaskBoard_DAO.UtenteDAO;
import UninaTaskBoard_Model.Utente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.geom.Path2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;

public class LoginFrame extends JFrame {

    private CardLayout cardLayout;
    private JPanel mainCardPanel;

    private JTextField txtLoginEmail;
    private JPasswordField txtLoginPassword;
    private JButton btnMostraPasswordLogin;

    private JTextField txtRegMatricola;
    private JTextField txtRegCF;
    private JTextField txtRegNome;
    private JTextField txtRegCognome;
    private JTextField txtRegEmail;
    private JPasswordField txtRegPassword;
    private JButton btnMostraPasswordRegistrazione;
    private JButton btnAccedi;
    private JButton btnRegistrati;
    private UtenteDAO utenteDAO;

    private final Color COLOR_BG = new Color(214, 230, 244);
    private final Color COLOR_PRIMARY = new Color(0, 28, 99);
    private final Color COLOR_TEXT_MAIN = new Color(0, 28, 99);
    private final Color COLOR_PLACEHOLDER = new Color(150, 150, 150);

    public LoginFrame() {
        AppTheme.apply();
        utenteDAO = new UtenteDAO();
        setTitle("UninaTaskBoard");
        setIconImage(caricaLogoIcona(512));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setPreferredSize(new Dimension(500, 700));

        JPanel outerPanel = new JPanel(new GridBagLayout()) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                g2.setPaint(new GradientPaint(0, 0, new Color(225, 237, 249), 0, getHeight(), new Color(242, 247, 252)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };

        cardLayout = new CardLayout();
        mainCardPanel = new JPanel(cardLayout);
        mainCardPanel.setOpaque(false);

        mainCardPanel.add(creaPannelloLogin(), "LOGIN");
        mainCardPanel.add(creaPannelloRegistrazione(), "REGISTRAZIONE");
        getRootPane().setDefaultButton(btnAccedi);

        outerPanel.add(mainCardPanel);
        add(outerPanel);

        pack();
        setLocationRelativeTo(null);
    }

    public void setLogoUrl(String url) {
        mostraScheda("LOGIN");
    }

    private JPanel creaPannelloLogin() {
        RoundedPanel card = new RoundedPanel(25, Color.WHITE);
        card.setLayout(new GridBagLayout());
        card.setBorder(new EmptyBorder(20, 25, 20, 25));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 6, 0);

        JLabel lblLogo = creaLabelLogo();
        lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(lblLogo, gbc);

        gbc.gridy++;
        JLabel lblTitle = new JLabel("UninaTaskBoard", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(COLOR_TEXT_MAIN);
        card.add(lblTitle, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 12, 0);
        JLabel lblSubtitle = new JLabel("Accedi al tuo account", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitle.setForeground(new Color(80, 80, 80));
        card.add(lblSubtitle, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 10, 0);
        txtLoginEmail = creaCampoTestoFormattato("Email");
        card.add(txtLoginEmail, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 14, 0);
        JPanel campoPasswordLogin = creaCampoPasswordFormattato("Password", false);
        card.add(campoPasswordLogin, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 12, 0);
        btnAccedi = new RoundedButton("Accedi", 12);
        btnAccedi.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnAccedi.setPreferredSize(new Dimension(280, 42));
        btnAccedi.addActionListener(e -> eseguiLogin());
        card.add(btnAccedi, gbc);
        txtLoginEmail.addActionListener(e -> txtLoginPassword.requestFocusInWindow());
        txtLoginPassword.addActionListener(e -> eseguiLogin());

        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 0, 0);
        JPanel pnlFooter = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        pnlFooter.setOpaque(false);

        JLabel lblQuestion = new JLabel("Non hai un account?");
        lblQuestion.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JLabel lblLinkReg = new JLabel("<html><u>Registrati</u></html>");
        lblLinkReg.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblLinkReg.setForeground(COLOR_PRIMARY);
        lblLinkReg.setCursor(new Cursor(Cursor.HAND_CURSOR));
        lblLinkReg.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                mostraScheda("REGISTRAZIONE");
            }
        });

        pnlFooter.add(lblQuestion);
        pnlFooter.add(lblLinkReg);
        card.add(pnlFooter, gbc);

        return card;
    }

    private JPanel creaPannelloRegistrazione() {
        RoundedPanel card = new RoundedPanel(25, Color.WHITE);
        card.setLayout(new GridBagLayout());
        card.setBorder(new EmptyBorder(18, 25, 18, 25));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 4, 0);

        JLabel lblLogo = creaLabelLogo();
        lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(lblLogo, gbc);

        gbc.gridy++;
        JLabel lblTitle = new JLabel("UninaTaskBoard", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(COLOR_TEXT_MAIN);
        card.add(lblTitle, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 8, 0);
        JLabel lblSubtitle = new JLabel("Crea il tuo account", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitle.setForeground(new Color(80, 80, 80));
        card.add(lblSubtitle, gbc);

        gbc.insets = new Insets(0, 0, 8, 0);

        txtRegMatricola = creaCampoTestoFormattato("Matricola");
        gbc.gridy++; card.add(txtRegMatricola, gbc);

        txtRegCF = creaCampoTestoFormattato("Codice Fiscale");
        gbc.gridy++; card.add(txtRegCF, gbc);

        txtRegNome = creaCampoTestoFormattato("Nome");
        gbc.gridy++; card.add(txtRegNome, gbc);

        txtRegCognome = creaCampoTestoFormattato("Cognome");
        gbc.gridy++; card.add(txtRegCognome, gbc);

        txtRegEmail = creaCampoTestoFormattato("Email");
        gbc.gridy++; card.add(txtRegEmail, gbc);

        gbc.insets = new Insets(0, 0, 10, 0);
        JPanel campoPasswordRegistrazione = creaCampoPasswordFormattato("Password", true);
        gbc.gridy++; card.add(campoPasswordRegistrazione, gbc);

        gbc.insets = new Insets(0, 0, 10, 0);
        btnRegistrati = new RoundedButton("Registrati", 12);
        btnRegistrati.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnRegistrati.setPreferredSize(new Dimension(280, 42));
        btnRegistrati.addActionListener(e -> eseguiRegistrazione());
        gbc.gridy++; card.add(btnRegistrati, gbc);
        txtRegMatricola.addActionListener(e -> txtRegCF.requestFocusInWindow());
        txtRegCF.addActionListener(e -> txtRegNome.requestFocusInWindow());
        txtRegNome.addActionListener(e -> txtRegCognome.requestFocusInWindow());
        txtRegCognome.addActionListener(e -> txtRegEmail.requestFocusInWindow());
        txtRegEmail.addActionListener(e -> txtRegPassword.requestFocusInWindow());
        txtRegPassword.addActionListener(e -> eseguiRegistrazione());

        gbc.insets = new Insets(0, 0, 0, 0);
        JPanel pnlFooter = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        pnlFooter.setOpaque(false);

        JLabel lblQuestion = new JLabel("Hai già un account?");
        lblQuestion.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JLabel lblLinkLogin = new JLabel("<html><u>Accedi</u></html>");
        lblLinkLogin.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblLinkLogin.setForeground(COLOR_PRIMARY);
        lblLinkLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        lblLinkLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                mostraScheda("LOGIN");
            }
        });

        pnlFooter.add(lblQuestion);
        pnlFooter.add(lblLinkLogin);
        gbc.gridy++; card.add(pnlFooter, gbc);

        return card;
    }

    private JLabel creaLabelLogo() {
        JLabel lbl = new JLabel();
        int logoSize = 130;
        Image image = caricaLogoIcona(logoSize);
        if (image != null) {
            lbl.setIcon(new ImageIcon(image));
        } else {
            lbl.setPreferredSize(new Dimension(logoSize, logoSize));
        }
        return lbl;
    }

    public static Image caricaLogoIcona(int dimensione) {
        return caricaLogoRisorsa("/assets/unina-task-board.png", dimensione);
    }

    public static Image caricaLogoDockIcona(int dimensione) {
        return caricaLogoRisorsa("/assets/unina-task-board-dock.png", dimensione);
    }

    public static Image caricaLogoSidebarIcona(int dimensione) {
        return caricaLogoRisorsa("/assets/unina-task-board-sidebar.png", dimensione);
    }

    private static Image caricaLogoRisorsa(String percorso, int dimensione) {
        try (InputStream input = LoginFrame.class.getResourceAsStream(percorso)) {
            if (input == null) {
                return null;
            }
            BufferedImage logo = ImageIO.read(input);
            return logo == null ? null : logo.getScaledInstance(dimensione, dimensione, Image.SCALE_SMOOTH);
        } catch (IOException e) {
            return null;
        }
    }

    private JTextField creaCampoTestoFormattato(String placeholder) {
        JTextField txt = new JTextField(placeholder);
        txt.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txt.setForeground(COLOR_PLACEHOLDER);
        txt.setPreferredSize(new Dimension(280, 42));
        txt.setBackground(new Color(248, 250, 253));
        txt.setOpaque(true);
        txt.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(207, 216, 228), 1, true),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));

        txt.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (txt.getText().equals(placeholder)) {
                    txt.setText("");
                    txt.setForeground(Color.BLACK);
                }
                txt.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(75, 115, 175), 1, true),
                        BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (txt.getText().isEmpty()) {
                    txt.setText(placeholder);
                    txt.setForeground(COLOR_PLACEHOLDER);
                }
                txt.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(207, 216, 228), 1, true),
                        BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            }
        });

        return txt;
    }

    private JPanel creaCampoPasswordFormattato(String placeholder, boolean registrazione) {
        JPasswordField txt = new JPasswordField();
        txt.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txt.setEchoChar((char) 0);
        txt.setText(placeholder);
        txt.setForeground(COLOR_PLACEHOLDER);
        txt.setBackground(new Color(248, 250, 253));
        txt.setOpaque(true);
        txt.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 4));
        txt.setPreferredSize(new Dimension(238, 40));

        JButton toggle = new JButton(new EyeIcon(false));
        toggle.setToolTipText("Mostra password");
        toggle.getAccessibleContext().setAccessibleName("Mostra password");
        toggle.setFocusable(false);
        toggle.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
        toggle.setContentAreaFilled(false);
        toggle.setCursor(new Cursor(Cursor.HAND_CURSOR));
        toggle.setPreferredSize(new Dimension(40, 40));
        if (registrazione) {
            txtRegPassword = txt;
            btnMostraPasswordRegistrazione = toggle;
        } else {
            txtLoginPassword = txt;
            btnMostraPasswordLogin = toggle;
        }

        JPanel campo = new JPanel(new BorderLayout());
        campo.setPreferredSize(new Dimension(280, 42));
        campo.setBackground(txt.getBackground());
        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(207, 216, 228), 1, true),
                BorderFactory.createEmptyBorder(0, 4, 0, 4)));
        campo.add(txt, BorderLayout.CENTER);
        campo.add(toggle, BorderLayout.EAST);

        boolean[] visibile = {false};
        toggle.addActionListener(e -> {
            if (txt.getForeground().equals(COLOR_PLACEHOLDER)) return;
            visibile[0] = !visibile[0];
            txt.setEchoChar(visibile[0] ? (char) 0 : '•');
            toggle.setIcon(new EyeIcon(visibile[0]));
            String descrizione = visibile[0] ? "Nascondi password" : "Mostra password";
            toggle.setToolTipText(descrizione);
            toggle.getAccessibleContext().setAccessibleName(descrizione);
        });

        txt.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                String pass = new String(txt.getPassword());
                if (pass.equals(placeholder)) {
                    txt.setText("");
                    txt.setEchoChar('•');
                    txt.setForeground(Color.BLACK);
                }
                campo.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(75, 115, 175), 1, true),
                        BorderFactory.createEmptyBorder(0, 4, 0, 4)));
            }

            @Override
            public void focusLost(FocusEvent e) {
                String pass = new String(txt.getPassword());
                if (pass.isEmpty()) {
                    visibile[0] = false;
                    txt.setEchoChar((char) 0);
                    txt.setText(placeholder);
                    txt.setForeground(COLOR_PLACEHOLDER);
                    toggle.setIcon(new EyeIcon(false));
                    toggle.setToolTipText("Mostra password");
                    toggle.getAccessibleContext().setAccessibleName("Mostra password");
                } else if (e.getOppositeComponent() != toggle) {
                    visibile[0] = false;
                    txt.setEchoChar('•');
                    toggle.setIcon(new EyeIcon(false));
                    toggle.setToolTipText("Mostra password");
                    toggle.getAccessibleContext().setAccessibleName("Mostra password");
                }
                campo.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(207, 216, 228), 1, true),
                        BorderFactory.createEmptyBorder(0, 4, 0, 4)));
            }
        });

        return campo;
    }

    private void mostraScheda(String nomeScheda) {
        nascondiPassword(txtLoginPassword, btnMostraPasswordLogin);
        nascondiPassword(txtRegPassword, btnMostraPasswordRegistrazione);
        cardLayout.show(mainCardPanel, nomeScheda);
        getRootPane().setDefaultButton("REGISTRAZIONE".equals(nomeScheda) ? btnRegistrati : btnAccedi);
    }

    private void nascondiPassword(JPasswordField campo, JButton pulsante) {
        if (campo == null || pulsante == null || campo.getForeground().equals(COLOR_PLACEHOLDER)) return;
        campo.setEchoChar('•');
        pulsante.setIcon(new EyeIcon(false));
        pulsante.setToolTipText("Mostra password");
        pulsante.getAccessibleContext().setAccessibleName("Mostra password");
    }

    private void eseguiLogin() {
        nascondiPassword(txtLoginPassword, btnMostraPasswordLogin);
        String email = txtLoginEmail.getText().trim();
        String password = new String(txtLoginPassword.getPassword());

        if (email.equals("Email") || password.equals("Password") || email.isEmpty() || password.isEmpty()) {
            mostraMessaggio("Attenzione", "Inserisci tutte le credenziali!", false);
            return;
        }

        Utente u = utenteDAO.login(email, password);
        if (u != null) {
            MainFrame mainFrame = new MainFrame(u);
            mainFrame.setVisible(true);
            this.dispose();
        } else {
            mostraMessaggio("Errore Login", "Credenziali non valide", true);
        }
    }

    private void eseguiRegistrazione() {
        nascondiPassword(txtRegPassword, btnMostraPasswordRegistrazione);
        String mat = txtRegMatricola.getText().trim();
        String cf = txtRegCF.getText().trim();
        String nome = txtRegNome.getText().trim();
        String cognome = txtRegCognome.getText().trim();
        String email = txtRegEmail.getText().trim();
        String pass = new String(txtRegPassword.getPassword());

        if (mat.equals("Matricola") || cf.equals("Codice Fiscale") || nome.equals("Nome") ||
            cognome.equals("Cognome") || email.equals("Email") || pass.equals("Password") ||
            mat.isEmpty() || cf.isEmpty() || nome.isEmpty() || cognome.isEmpty() || email.isEmpty() || pass.isEmpty()) {
            mostraMessaggio("Attenzione", "Compilare tutti i campi obbligatori!", false);
            return;
        }

        if (pass.length() < 8 || pass.length() > 128) {
            mostraMessaggio("Password non valida", "La password deve contenere da 8 a 128 caratteri.", true);
            return;
        }

        if (!utenteDAO.isEmailIstituzionale(email)) {
            mostraMessaggio("Email istituzionale richiesta",
                    "Per registrarti usa un indirizzo che termina con @studenti.unina.it.", true);
            return;
        }

        if (utenteDAO.getUtenteByMatricola(mat) != null) {
            mostraMessaggio("Errore Registrazione", "Matricola già registrata!", true);
            return;
        }

        if (utenteDAO.getUtenteByEmail(email) != null) {
            mostraMessaggio("Errore Registrazione", "Email già registrata!", true);
            return;
        }

        Utente u = new Utente(mat, cf, nome, cognome, email, pass);
        if (utenteDAO.creaUtente(u)) {
            mostraMessaggio("Registrazione completata", "Registrazione completata! Effettua il login.", false);
            mostraScheda("LOGIN");
        } else {
            mostraMessaggio("Errore DB", "Errore durante il salvataggio dei dati.", true);
        }
    }

    private void mostraMessaggio(String titolo, String testo, boolean errore) {
        CustomDialog dialog = new CustomDialog(this, titolo);
        JPanel content = dialog.getContentPanel();
        content.setLayout(new BorderLayout(0, 12));
        JLabel message = new JLabel(testo);
        message.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        if (errore) message.setForeground(new Color(180, 45, 45));
        content.add(message, BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);
        RoundedButton close = new RoundedButton("Chiudi", 10);
        close.addActionListener(e -> dialog.dispose());
        actions.add(close);
        content.add(actions, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private static class EyeIcon implements Icon {
        private final boolean aperto;
        private final Color colore = new Color(0, 28, 99);

        private EyeIcon(boolean aperto) {
            this.aperto = aperto;
        }

        @Override
        public int getIconWidth() {
            return 20;
        }

        @Override
        public int getIconHeight() {
            return 18;
        }

        @Override
        public void paintIcon(Component componente, Graphics graphics, int x, int y) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(colore);
            g.setStroke(new BasicStroke(1.7f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            Path2D forma = new Path2D.Float();
            if (aperto) {
                forma.moveTo(x + 1, y + 9);
                forma.curveTo(x + 5, y + 2, x + 15, y + 2, x + 19, y + 9);
                forma.curveTo(x + 15, y + 16, x + 5, y + 16, x + 1, y + 9);
                forma.closePath();
                g.draw(forma);
                g.fillOval(x + 7, y + 6, 6, 6);
                g.setColor(Color.WHITE);
                g.fillOval(x + 8, y + 7, 2, 2);
            } else {
                forma.moveTo(x + 1, y + 10);
                forma.curveTo(x + 6, y + 5, x + 14, y + 5, x + 19, y + 10);
                g.draw(forma);
                g.drawLine(x + 5, y + 7, x + 4, y + 4);
                g.drawLine(x + 10, y + 6, x + 10, y + 3);
                g.drawLine(x + 15, y + 7, x + 16, y + 4);
            }
            g.dispose();
        }
    }

    public static class RoundedPanel extends JPanel {
        private int cornerRadius;
        private Color backgroundColor;

        public RoundedPanel(int radius, Color bgColor) {
            super();
            this.cornerRadius = radius;
            this.backgroundColor = bgColor;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(backgroundColor);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius);
            g2.setColor(new Color(18, 43, 77, 20));
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, cornerRadius, cornerRadius);
            g2.dispose();
        }
    }

    public static class RoundedButton extends JButton {
        private int cornerRadius;
        private Color baseColor;
        private Color hoverColor;

        public RoundedButton(String text, int radius) {
            this(text, radius, new Color(0, 28, 99), new Color(0, 20, 72), Color.WHITE);
        }

        public RoundedButton(String text, int radius, Color baseColor, Color hoverColor, Color foreground) {
            super(text);
            this.cornerRadius = radius;
            this.baseColor = baseColor;
            this.hoverColor = hoverColor;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setBackground(baseColor);
            setForeground(foreground);
            setFont(new Font("Segoe UI", Font.BOLD, 13));

            addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseEntered(java.awt.event.MouseEvent e) {
                    setBackground(hoverColor);
                }

                @Override
                public void mouseExited(java.awt.event.MouseEvent e) {
                    setBackground(baseColor);
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}
