package UninaTaskBoard_DAO;

import UninaTaskBoard_DB.DataBaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class ReportDAO {
    public int[] getConteggiAttivita(int idProg) {
        int[] conteggi = new int[4];
        String sql = "SELECT COUNT(*) AS Totali, "
                + "COUNT(*) FILTER (WHERE StatoAvanzamento = 'Iniziato') AS Iniziate, "
                + "COUNT(*) FILTER (WHERE StatoAvanzamento = 'In Corso') AS InCorso, "
                + "COUNT(*) FILTER (WHERE StatoAvanzamento = 'Finito') AS Finite, "
                + "COUNT(*) FILTER (WHERE TipoAttivita = 'Sviluppo') AS Sviluppo "
                + "FROM Attivita WHERE IDProg = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idProg);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    conteggi[0] = rs.getInt("Totali");
                    conteggi[1] = rs.getInt("Iniziate");
                    conteggi[2] = rs.getInt("InCorso");
                    conteggi[3] = rs.getInt("Finite");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conteggi;
    }

    public int getNumeroAttivitaSviluppo(int idProg) {
        String sql = "SELECT COUNT(*) FROM Attivita WHERE IDProg = ? AND TipoAttivita = 'Sviluppo'";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idProg);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public double getMediaRevisioniPerFileCodice(int idProg) {
        String sql = "SELECT COALESCE(AVG(r.NumeroRevisioni), 0) FROM ("
                + "SELECT a.IDAttivita, COUNT(rv.IDRevisione) AS NumeroRevisioni "
                + "FROM Attivita a LEFT JOIN Revisione rv ON rv.IDAttivita = a.IDAttivita "
                + "WHERE a.IDProg = ? AND a.TipoAttivita = 'Sviluppo' GROUP BY a.IDAttivita) r";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idProg);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public Map<String, Integer> getAttivitaFinitePerMembro(int idProg) {
        Map<String, Integer> risultati = new LinkedHashMap<>();
        String sql = "SELECT u.Nome, u.Cognome, u.Matricola, COUNT(DISTINCT a.IDAttivita) AS Totale "
                + "FROM Svolge s JOIN Attivita a ON a.IDAttivita = s.IDAttivita "
                + "JOIN Utente u ON u.Matricola = s.Matricola "
                + "WHERE a.IDProg = ? AND a.StatoAvanzamento = 'Finito' "
                + "GROUP BY u.Nome, u.Cognome, u.Matricola ORDER BY u.Cognome, u.Nome";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idProg);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String nome = rs.getString("Nome") + " " + rs.getString("Cognome")
                            + " (" + rs.getString("Matricola") + ")";
                    risultati.put(nome, rs.getInt("Totale"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return risultati;
    }
}
