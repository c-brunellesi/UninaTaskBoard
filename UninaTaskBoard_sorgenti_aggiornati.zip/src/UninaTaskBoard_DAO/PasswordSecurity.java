package UninaTaskBoard_DAO;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

public final class PasswordSecurity {
    private static final int ITERAZIONI = 210000;
    private static final int DIMENSIONE_HASH = 256;
    private static final int DIMENSIONE_SALT = 16;
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final String PREFISSO = "UTB$PBKDF2$";

    private PasswordSecurity() {
    }

    public static String creaHash(String password) {
        byte[] salt = new byte[DIMENSIONE_SALT];
        RANDOM.nextBytes(salt);
        byte[] hash = deriva(password.toCharArray(), salt, ITERAZIONI);
        return PREFISSO + ITERAZIONI + "$" + Base64.getEncoder().encodeToString(salt)
                + "$" + Base64.getEncoder().encodeToString(hash);
    }

    public static boolean verifica(String password, String valoreSalvato) {
        if (password == null || valoreSalvato == null) return false;
        if (!valoreSalvato.startsWith(PREFISSO)) {
            return MessageDigest.isEqual(password.getBytes(java.nio.charset.StandardCharsets.UTF_8),
                    valoreSalvato.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }
        try {
            String[] parti = valoreSalvato.split("\\$");
            int iterazioni = Integer.parseInt(parti[2]);
            byte[] salt = Base64.getDecoder().decode(parti[3]);
            byte[] hashAtteso = Base64.getDecoder().decode(parti[4]);
            byte[] hashInserito = deriva(password.toCharArray(), salt, iterazioni);
            return MessageDigest.isEqual(hashAtteso, hashInserito);
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static boolean eHash(String valore) {
        return valore != null && valore.startsWith(PREFISSO);
    }

    private static byte[] deriva(char[] password, byte[] salt, int iterazioni) {
        PBEKeySpec spec = new PBEKeySpec(password, salt, iterazioni, DIMENSIONE_HASH);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (Exception e) {
            throw new IllegalStateException("Impossibile proteggere la password", e);
        } finally {
            spec.clearPassword();
            java.util.Arrays.fill(password, '\0');
        }
    }
}
