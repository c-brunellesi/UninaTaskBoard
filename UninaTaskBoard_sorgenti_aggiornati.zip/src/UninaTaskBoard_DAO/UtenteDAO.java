package UninaTaskBoard_DAO;

import UninaTaskBoard_DB.DataBaseConnection;
import UninaTaskBoard_Model.Utente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UtenteDAO {

    public Utente login(String email, String password) {
        String query = "SELECT * FROM UTENTE WHERE email = ?";
        Utente utente = null;
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    utente = new Utente(
                            rs.getString("matricola"),
                            rs.getString("cf"),
                            rs.getString("nome"),
                            rs.getString("cognome"),
                            rs.getString("email"),
                            rs.getString("password")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (utente == null || !PasswordSecurity.verifica(password, utente.getPassword())) return null;
        if (!PasswordSecurity.eHash(utente.getPassword())) {
            String hash = PasswordSecurity.creaHash(password);
            if (aggiornaPasswordHash(utente.getMatricola(), hash)) utente.setPassword(hash);
        }
        return utente;
    }

    public boolean creaUtente(Utente utente) {
        if (!isEmailIstituzionale(utente.getEmail())) return false;
        String query = "INSERT INTO UTENTE (matricola, cf, nome, cognome, email, password) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, utente.getMatricola());
            ps.setString(2, utente.getCf());
            ps.setString(3, utente.getNome());
            ps.setString(4, utente.getCognome());
            ps.setString(5, utente.getEmail());
            ps.setString(6, PasswordSecurity.creaHash(utente.getPassword()));

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("ERRORE DB: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    public boolean cambiaPassword(String matricola, String password) {
        return aggiornaPasswordHash(matricola, PasswordSecurity.creaHash(password));
    }

    private boolean aggiornaPasswordHash(String matricola, String hash) {
        String query = "UPDATE UTENTE SET Password = ? WHERE Matricola = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, hash);
            ps.setString(2, matricola);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isEmailIstituzionale(String email) {
        return email != null && email.trim().toLowerCase(java.util.Locale.ROOT).matches(
                "^[^\\s@]+@studenti\\.unina\\.it$");
    }

    public Utente getUtenteByMatricola(String matricola) {
        String query = "SELECT * FROM UTENTE WHERE matricola = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, matricola);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Utente(
                            rs.getString("matricola"),
                            rs.getString("cf"),
                            rs.getString("nome"),
                            rs.getString("cognome"),
                            rs.getString("email"),
                            rs.getString("password")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Utente getUtenteByEmail(String email) {
        String query = "SELECT * FROM UTENTE WHERE email = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Utente(
                            rs.getString("matricola"),
                            rs.getString("cf"),
                            rs.getString("nome"),
                            rs.getString("cognome"),
                            rs.getString("email"),
                            rs.getString("password")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Utente> getUtentiPartecipantiProgetto(int idProg) {
        List<Utente> utenti = new ArrayList<>();
        String query = "SELECT DISTINCT u.Matricola, u.CF, u.Nome, u.Cognome, u.Email FROM Utente u "
                + "JOIN Partecipa p ON p.Matricola = u.Matricola WHERE p.IDProg = ? "
                + "UNION SELECT u.Matricola, u.CF, u.Nome, u.Cognome, u.Email FROM Utente u "
                + "JOIN Progetto p ON p.Matricola_Dirigente = u.Matricola WHERE p.IDProg = ? "
                + "ORDER BY Cognome, Nome";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, idProg);
            ps.setInt(2, idProg);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    utenti.add(new Utente(rs.getString("Matricola"), rs.getString("CF"),
                            rs.getString("Nome"), rs.getString("Cognome"),
                            rs.getString("Email"), null));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return utenti;
    }

    public List<Utente> cercaUtentiPerInvito(String testo, int idProg, String matricolaEsclusa) {
        List<Utente> utenti = new ArrayList<>();
        String query = "SELECT u.Matricola, u.CF, u.Nome, u.Cognome, u.Email FROM Utente u "
                + "WHERE (u.Nome ILIKE ? OR u.Cognome ILIKE ? OR u.Matricola ILIKE ? "
                + "OR (u.Nome || ' ' || u.Cognome) ILIKE ?) "
                + "AND u.Matricola <> ? "
                + "ORDER BY u.Cognome, u.Nome LIMIT 15";
        String filtro = "%" + testo.trim() + "%";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, filtro);
            ps.setString(2, filtro);
            ps.setString(3, filtro);
            ps.setString(4, filtro);
            ps.setString(5, matricolaEsclusa);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    utenti.add(new Utente(rs.getString("Matricola"), rs.getString("CF"),
                            rs.getString("Nome"), rs.getString("Cognome"), rs.getString("Email"), null));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return utenti;
    }
}
