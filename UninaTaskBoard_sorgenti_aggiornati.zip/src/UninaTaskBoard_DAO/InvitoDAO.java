package UninaTaskBoard_DAO;

import UninaTaskBoard_DB.DataBaseConnection;
import UninaTaskBoard_Model.Invito;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class InvitoDAO {

    public int getConteggioInvitiRicevutiPendenti(String matricolaDestinatario) {
        String sql = "SELECT COUNT(*) FROM Invita WHERE MatricolaInvitato = ? AND Stato = 'In Attesa'";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, matricolaDestinatario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public Invito getInvitoById(int idInvito) {
        String sql = "SELECT * FROM Invita WHERE IDInvito = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idInvito);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSetToInvito(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Invito> getInvitiRicevutiPendenti(String matricolaDestinatario) {
        return getInviti("MatricolaInvitato = ? AND Stato = 'In Attesa'", matricolaDestinatario);
    }

    public List<Invito> getTuttiInvitiRicevuti(String matricolaDestinatario) {
        return getInviti("MatricolaInvitato = ?", matricolaDestinatario);
    }

    public List<Invito> getInvitiInviati(String matricolaInvitante) {
        return getInviti("MatricolaInvitante = ?", matricolaInvitante);
    }

    private List<Invito> getInviti(String condizione, String matricola) {
        List<Invito> lista = new ArrayList<>();
        String sql = "SELECT * FROM Invita WHERE IDProg IS NOT NULL AND " + condizione + " ORDER BY DataInvito DESC, IDInvito DESC";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, matricola);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapResultSetToInvito(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean esisteInvitoPendente(String destinatario, int idProg) {
        String sql = "SELECT 1 FROM Invita WHERE MatricolaInvitato = ? AND IDProg = ? AND Stato = 'In Attesa'";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, destinatario);
            ps.setInt(2, idProg);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean inviaInvito(Invito invito) {
        String sql = "INSERT INTO Invita (MatricolaInvitante, MatricolaInvitato, IDProg, Stato, DataInvito) "
                + "SELECT ?, ?, p.IDProg, 'In Attesa', CURRENT_DATE FROM Progetto p "
                + "WHERE p.IDProg = ? AND p.Matricola_Dirigente = ? "
                + "AND (p.DataScadenza IS NULL OR CURRENT_DATE <= p.DataScadenza) "
                + "AND NOT EXISTS (SELECT 1 FROM Partecipa pa WHERE pa.Matricola = ? AND pa.IDProg = p.IDProg) "
                + "ON CONFLICT (MatricolaInvitato, IDProg) WHERE IDProg IS NOT NULL AND Stato = 'In Attesa' "
                + "DO UPDATE SET MatricolaInvitante = EXCLUDED.MatricolaInvitante, DataInvito = CURRENT_DATE "
                + "RETURNING IDInvito";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, invito.getMatricolaInvitante());
            ps.setString(2, invito.getMatricolaDestinatario());
            ps.setInt(3, invito.getIdProg());
            ps.setString(4, invito.getMatricolaInvitante());
            ps.setString(5, invito.getMatricolaDestinatario());
            if (!ps.execute()) return false;
            try (ResultSet keys = ps.getResultSet()) {
                if (keys == null || !keys.next()) return false;
                invito.setIdInvito(keys.getInt("IDInvito"));
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean accettaInvito(int idInvito, String matricola, int idProg) {
        String update = "UPDATE Invita SET Stato = 'Accettato' WHERE IDInvito = ? AND MatricolaInvitato = ? AND IDProg = ? AND Stato = 'In Attesa'";
        String partecipa = "INSERT INTO Partecipa (Matricola, IDProg, InizioPartecipazione) "
                + "SELECT ?, p.IDProg, GREATEST(CURRENT_DATE, p.DataInizio) FROM Progetto p "
                + "WHERE p.IDProg = ? AND (p.DataScadenza IS NULL OR GREATEST(CURRENT_DATE, p.DataInizio) <= p.DataScadenza) "
                + "ON CONFLICT (Matricola, IDProg) DO NOTHING";
        try (Connection conn = DataBaseConnection.getInstance().getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement check = conn.prepareStatement("SELECT 1 FROM Invita WHERE IDInvito = ? AND MatricolaInvitato = ? AND IDProg = ? AND Stato = 'In Attesa' FOR UPDATE")) {
                check.setInt(1, idInvito);
                check.setString(2, matricola);
                check.setInt(3, idProg);
                try (ResultSet rs = check.executeQuery()) {
                    if (!rs.next()) { conn.rollback(); return false; }
                }
                try (PreparedStatement ps = conn.prepareStatement(partecipa);
                     PreparedStatement psUpdate = conn.prepareStatement(update)) {
                    ps.setString(1, matricola);
                    ps.setInt(2, idProg);
                    if (ps.executeUpdate() != 1) { conn.rollback(); return false; }
                    psUpdate.setInt(1, idInvito);
                    psUpdate.setString(2, matricola);
                    psUpdate.setInt(3, idProg);
                    if (psUpdate.executeUpdate() != 1) { conn.rollback(); return false; }
                }
                conn.commit();
                return true;
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean rifiutaInvito(int idInvito) {
        String sql = "UPDATE Invita SET Stato = 'Rifiutato' WHERE IDInvito = ? AND Stato = 'In Attesa'";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idInvito);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminaInvito(int idInvito) {
        String sql = "DELETE FROM Invita WHERE IDInvito = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idInvito);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Invito mapResultSetToInvito(ResultSet rs) throws SQLException {
        return new Invito(rs.getInt("IDInvito"), rs.getString("MatricolaInvitante"),
                rs.getString("MatricolaInvitato"), rs.getInt("IDProg"), rs.getString("Stato"), null);
    }
}
