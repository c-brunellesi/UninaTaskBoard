package UninaTaskBoard_DAO;

import UninaTaskBoard_DB.DataBaseConnection;
import UninaTaskBoard_Model.Revisione;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class RevisioneDAO {
    public List<Revisione> getRevisioniPerAttivita(int idAttivita) {
        List<Revisione> revisioni = new ArrayList<>();
        String sql = "SELECT r.*, u.Nome, u.Cognome FROM Revisione r "
                + "LEFT JOIN Utente u ON u.Matricola = r.MatricolaAutore "
                + "WHERE r.IDAttivita = ? ORDER BY r.Data DESC, r.IDRevisione DESC";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idAttivita);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Revisione revisione = new Revisione(rs.getInt("IDRevisione"), rs.getDate("Data"), null,
                            rs.getString("DescrizioneIntervento"), rs.getString("MatricolaAutore"),
                            rs.getInt("IDAttivita"));
                    String nome = rs.getString("Nome");
                    String cognome = rs.getString("Cognome");
                    revisione.setNomeAutore(nome == null ? revisione.getMatricolaRevisore() : nome + " " + cognome);
                    revisione.setCodiceSorgente(rs.getString("CodiceSorgente"));
                    revisioni.add(revisione);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return revisioni;
    }

    public List<Revisione> getRevisioniPerProgetto(int idProg) {
        List<Revisione> revisioni = new ArrayList<>();
        String sql = "SELECT r.*, u.Nome AS NomeAutore, u.Cognome AS CognomeAutore, a.Nome AS NomeAttivita "
                + "FROM Revisione r JOIN Attivita a ON a.IDAttivita = r.IDAttivita "
                + "LEFT JOIN Utente u ON u.Matricola = r.MatricolaAutore "
                + "WHERE a.IDProg = ? ORDER BY r.Data DESC, r.IDRevisione DESC";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idProg);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Revisione revisione = new Revisione(rs.getInt("IDRevisione"), rs.getDate("Data"), null,
                            rs.getString("DescrizioneIntervento"), rs.getString("MatricolaAutore"),
                            rs.getInt("IDAttivita"));
                    String nome = rs.getString("NomeAutore");
                    String cognome = rs.getString("CognomeAutore");
                    revisione.setNomeAutore(nome == null ? revisione.getMatricolaRevisore() : nome + " " + cognome);
                    revisione.setCodiceSorgente(rs.getString("CodiceSorgente"));
                    revisione.setNomeAttivita(rs.getString("NomeAttivita"));
                    revisioni.add(revisione);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return revisioni;
    }

    public boolean salvaCodiceConRevisione(int idAttivita, String codice, String matricolaAutore) {
        return salvaCodiceConRevisione(idAttivita, codice, "Aggiornamento del codice sorgente", matricolaAutore);
    }

    public boolean salvaCodiceConRevisione(int idAttivita, String codice, String descrizioneIntervento, String matricolaAutore) {
        String sqlCodice = "UPDATE Attivita a SET CodiceSorgente = ? FROM Progetto p "
                + "JOIN Partecipa pa ON pa.IDProg = p.IDProg "
                + "WHERE a.IDAttivita = ? AND p.IDProg = a.IDProg AND pa.Matricola = ? "
                + "AND a.TipoAttivita = 'Sviluppo' AND a.StatoAvanzamento <> 'Finito'::StatoAvanzamentoEnum";
        String sqlRevisione = "INSERT INTO Revisione (DescrizioneIntervento, CodiceSorgente, Data, MatricolaAutore, IDAttivita) "
                + "VALUES (?, ?, CURRENT_DATE, ?, ?)";
        try (Connection conn = DataBaseConnection.getInstance().getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement update = conn.prepareStatement(sqlCodice);
                 PreparedStatement insert = conn.prepareStatement(sqlRevisione, Statement.RETURN_GENERATED_KEYS)) {
                update.setString(1, codice);
                update.setInt(2, idAttivita);
                update.setString(3, matricolaAutore);
                if (update.executeUpdate() != 1) {
                    conn.rollback();
                    return false;
                }
                insert.setString(1, descrizioneIntervento);
                insert.setString(2, codice);
                insert.setString(3, matricolaAutore);
                insert.setInt(4, idAttivita);
                if (insert.executeUpdate() != 1) {
                    conn.rollback();
                    return false;
                }
                conn.commit();
                return true;
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
