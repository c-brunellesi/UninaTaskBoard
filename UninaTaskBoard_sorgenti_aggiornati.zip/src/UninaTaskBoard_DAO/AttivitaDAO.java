package UninaTaskBoard_DAO;

import UninaTaskBoard_DB.DataBaseConnection;
import UninaTaskBoard_Model.Attivita;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AttivitaDAO {

    public Attivita getAttivitaById(int idAttivita) {
        String sql = "SELECT * FROM Attivita WHERE IDAttivita = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idAttivita);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToAttivita(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Attivita> getAttivitaPerProgetto(int idProgetto) {
        List<Attivita> lista = new ArrayList<>();
        String sql = "SELECT * FROM Attivita WHERE IDProg = ? ORDER BY Scadenza ASC";

        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idProgetto);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapResultSetToAttivita(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Attivita> getAttivitaPerUtente(String matricolaUtente) {
        List<Attivita> lista = new ArrayList<>();
        String sql = "SELECT * FROM Attivita WHERE IDProg IN ("
                   + "  SELECT IDProg FROM PARTECIPA WHERE Matricola = ? "
                   + "  UNION "
                   + "  SELECT IDProg FROM PROGETTO WHERE Matricola_Dirigente = ?"
                   + ") ORDER BY Scadenza ASC";

        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, matricolaUtente);
            ps.setString(2, matricolaUtente);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapResultSetToAttivita(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public Map<Integer, List<String>> getAssegnatariPerUtente(String matricolaUtente) {
        Map<Integer, List<String>> assegnatari = new LinkedHashMap<>();
        String sql = "SELECT s.IDAttivita, s.Matricola FROM Svolge s JOIN Attivita a ON a.IDAttivita = s.IDAttivita "
                   + "JOIN Progetto p ON p.IDProg = a.IDProg WHERE p.Matricola_Dirigente = ? "
                   + "OR EXISTS (SELECT 1 FROM Partecipa pa WHERE pa.IDProg = a.IDProg AND pa.Matricola = ?)";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, matricolaUtente);
            ps.setString(2, matricolaUtente);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    assegnatari.computeIfAbsent(rs.getInt("IDAttivita"), id -> new ArrayList<>())
                            .add(rs.getString("Matricola"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return assegnatari;
    }

    public List<String> getMatricoleAssegnate(int idAttivita) {
        List<String> matricole = new ArrayList<>();
        String sql = "SELECT Matricola FROM Svolge WHERE IDAttivita = ? ORDER BY Matricola";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idAttivita);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) matricole.add(rs.getString("Matricola"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return matricole;
    }

    public boolean aggiornaAssegnatari(Attivita attivita, List<String> matricole) {
        String elimina = "DELETE FROM Svolge WHERE IDAttivita = ?";
        String assicuraDirigente = "INSERT INTO Partecipa (Matricola, IDProg, InizioPartecipazione) "
                + "SELECT p.Matricola_Dirigente, p.IDProg, p.DataInizio FROM Progetto p "
                + "WHERE p.IDProg = ? AND p.Matricola_Dirigente = ? AND NOT EXISTS "
                + "(SELECT 1 FROM Partecipa pa WHERE pa.IDProg = p.IDProg AND pa.Matricola = p.Matricola_Dirigente)";
        String inserisci = "INSERT INTO Svolge (Matricola, IDAttivita) VALUES (?, ?)";
        try (Connection conn = DataBaseConnection.getInstance().getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement verifica = conn.prepareStatement(
                    "SELECT StatoAvanzamento FROM Attivita WHERE IDAttivita = ? FOR UPDATE")) {
                verifica.setInt(1, attivita.getIdAttivita());
                try (ResultSet rs = verifica.executeQuery()) {
                    if (!rs.next() || "Finito".equals(rs.getString(1))) {
                        conn.rollback();
                        return false;
                    }
                }
            }
            try (PreparedStatement psElimina = conn.prepareStatement(elimina);
                 PreparedStatement psAssicura = conn.prepareStatement(assicuraDirigente);
                 PreparedStatement psInserisci = conn.prepareStatement(inserisci)) {
                psElimina.setInt(1, attivita.getIdAttivita());
                psElimina.executeUpdate();
                for (String matricola : matricole) {
                    psAssicura.setInt(1, attivita.getIdProg());
                    psAssicura.setString(2, matricola);
                    psAssicura.executeUpdate();
                    psInserisci.setString(1, matricola);
                    psInserisci.setInt(2, attivita.getIdAttivita());
                    psInserisci.addBatch();
                }
                psInserisci.executeBatch();
                conn.commit();
                return true;
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean aggiornaDocumento(int idAttivita, String documento) {
        String sql = "UPDATE Attivita SET URLFile = ? WHERE IDAttivita = ? AND TipoAttivita = 'Documentazione' "
                + "AND StatoAvanzamento <> 'Finito'::StatoAvanzamentoEnum";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, documento);
            ps.setInt(2, idAttivita);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean creaAttivita(Attivita a) {
        String sql = "INSERT INTO Attivita (Nome, Descrizione, DataCreazione, Scadenza, StatoAvanzamento, TipoAttivita, CodiceSorgente, URLFile, IDProg) "
                   + "SELECT ?, ?, ?, ?, ?::StatoAvanzamentoEnum, ?::TipoAttivitaEnum, ?, ?, p.IDProg FROM Progetto p "
                   + "WHERE p.IDProg = ? AND ((p.TipoProgetto = 'Sviluppo'::TipoProgettoEnum AND ?::TipoAttivitaEnum = 'Sviluppo'::TipoAttivitaEnum) "
                   + "OR (p.TipoProgetto <> 'Sviluppo'::TipoProgettoEnum AND ?::TipoAttivitaEnum = 'Documentazione'::TipoAttivitaEnum))";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, a.getTitolo());
            ps.setString(2, a.getDescrizione());

            if (a.getDataInizio() != null) {
                ps.setDate(3, new java.sql.Date(a.getDataInizio().getTime()));
            } else {
                ps.setNull(3, Types.DATE);
            }

            if (a.getDataScadenza() != null) {
                ps.setDate(4, new java.sql.Date(a.getDataScadenza().getTime()));
            } else {
                ps.setNull(4, Types.DATE);
            }

            ps.setString(5, a.getStato());
            ps.setString(6, a.getTipoAttivita());
            ps.setString(7, a.getCodiceModulo());
            ps.setString(8, a.getUrlDocumento());
            ps.setInt(9, a.getIdProg());
            ps.setString(10, a.getTipoAttivita());
            ps.setString(11, a.getTipoAttivita());

            int affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        a.setIdAttivita(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean aggiornaAttivita(Attivita a) {
        String sql = "UPDATE Attivita att SET Nome = ?, Descrizione = ?, DataCreazione = ?, Scadenza = ?, "
                   + "StatoAvanzamento = ?::StatoAvanzamentoEnum, TipoAttivita = ?::TipoAttivitaEnum, CodiceSorgente = ?, URLFile = ? "
                   + "FROM Progetto p WHERE att.IDAttivita = ? AND p.IDProg = att.IDProg "
                   + "AND ((p.TipoProgetto = 'Sviluppo'::TipoProgettoEnum AND ?::TipoAttivitaEnum = 'Sviluppo'::TipoAttivitaEnum) "
                   + "OR (p.TipoProgetto <> 'Sviluppo'::TipoProgettoEnum AND ?::TipoAttivitaEnum = 'Documentazione'::TipoAttivitaEnum)) "
                   + "AND att.StatoAvanzamento <> 'Finito'::StatoAvanzamentoEnum";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, a.getTitolo());
            ps.setString(2, a.getDescrizione());

            if (a.getDataInizio() != null) {
                ps.setDate(3, new java.sql.Date(a.getDataInizio().getTime()));
            } else {
                ps.setNull(3, Types.DATE);
            }

            if (a.getDataScadenza() != null) {
                ps.setDate(4, new java.sql.Date(a.getDataScadenza().getTime()));
            } else {
                ps.setNull(4, Types.DATE);
            }

            ps.setString(5, a.getStato());
            ps.setString(6, a.getTipoAttivita());
            ps.setString(7, a.getCodiceModulo());
            ps.setString(8, a.getUrlDocumento());
            ps.setInt(9, a.getIdAttivita());
            ps.setString(10, a.getTipoAttivita());
            ps.setString(11, a.getTipoAttivita());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean aggiornaStatoAttivita(int idAttivita, String nuovoStato) {
        String sql = "UPDATE Attivita SET StatoAvanzamento = ?::StatoAvanzamentoEnum WHERE IDAttivita = ? "
                + "AND StatoAvanzamento <> 'Finito'::StatoAvanzamentoEnum";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nuovoStato);
            ps.setInt(2, idAttivita);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminaAttivita(int idAttivita) {
        String sql = "DELETE FROM Attivita WHERE IDAttivita = ? AND StatoAvanzamento <> 'Finito'::StatoAvanzamentoEnum";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idAttivita);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Attivita mapResultSetToAttivita(ResultSet rs) throws SQLException {
        return new Attivita(
            rs.getInt("IDAttivita"),
            rs.getString("Nome"),
            rs.getString("Descrizione"),
            rs.getDate("DataCreazione"),
            rs.getDate("Scadenza"),
            rs.getString("StatoAvanzamento"),
            rs.getString("TipoAttivita"),
            rs.getString("CodiceSorgente"),
            rs.getString("URLFile"),
            rs.getInt("IDProg")
        );
    }
}
