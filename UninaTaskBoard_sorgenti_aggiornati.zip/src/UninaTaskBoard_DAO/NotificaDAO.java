package UninaTaskBoard_DAO;

import UninaTaskBoard_DB.DataBaseConnection;
import UninaTaskBoard_Model.Notifica;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class NotificaDAO {

    public List<Notifica> getNotificheUtente(String matricola) {
        List<Notifica> lista = new ArrayList<>();
        String sql = "SELECT * FROM NOTIFICA WHERE matricola_destinatario = ? ORDER BY data_ora DESC";

        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, matricola);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapResultSetToNotifica(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Notifica> getNotificheNonLetteUtente(String matricola) {
        List<Notifica> lista = new ArrayList<>();
        String sql = "SELECT * FROM NOTIFICA WHERE matricola_destinatario = ? AND letta = false ORDER BY data_ora DESC";

        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, matricola);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapResultSetToNotifica(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public int getConteggioNotificheNonLette(String matricola) {
        String sql = "SELECT COUNT(*) FROM NOTIFICA WHERE matricola_destinatario = ? AND letta = false";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, matricola);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean creaNotifica(Notifica n) {
        String sql = "INSERT INTO NOTIFICA (messaggio, data_ora, letta, matricola_destinatario) VALUES (?, ?, ?, ?)";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, n.getMessaggio());
            ps.setTimestamp(2, n.getDataOra() != null ? new Timestamp(n.getDataOra().getTime()) : new Timestamp(System.currentTimeMillis()));
            ps.setBoolean(3, n.isLetta());
            ps.setString(4, n.getMatricolaDestinatario());

            int affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        n.setIdNotifica(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean segnaComeLetta(int idNotifica) {
        String sql = "UPDATE NOTIFICA SET letta = true WHERE id_notifica = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idNotifica);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean segnaTutteComeLette(String matricola) {
        String sql = "UPDATE NOTIFICA SET letta = true WHERE matricola_destinatario = ? AND letta = false";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, matricola);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminaNotifica(int idNotifica) {
        String sql = "DELETE FROM NOTIFICA WHERE id_notifica = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idNotifica);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Notifica mapResultSetToNotifica(ResultSet rs) throws SQLException {
        return new Notifica(
            rs.getInt("id_notifica"),
            rs.getString("messaggio"),
            rs.getTimestamp("data_ora"),
            rs.getBoolean("letta"),
            rs.getString("matricola_destinatario")
        );
    }
}