package UninaTaskBoard_DAO;

import UninaTaskBoard_DB.DataBaseConnection;
import UninaTaskBoard_Model.Commento;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CommentoDAO {
    public List<Commento> getCommentiPerAttivita(int idAttivita) {
        List<Commento> commenti = new ArrayList<>();
        String sql = "SELECT * FROM Commento WHERE IDAttivita = ? ORDER BY Data, IDCommento";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idAttivita);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    commenti.add(new Commento(rs.getInt("IDCommento"), rs.getString("Descrizione"),
                            rs.getDate("Data"), rs.getString("MatricolaAutore"), rs.getInt("IDAttivita")));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return commenti;
    }

    public boolean creaCommento(Commento commento) {
        String verifica = "SELECT StatoAvanzamento FROM Attivita WHERE IDAttivita = ? FOR UPDATE";
        String sql = "INSERT INTO Commento (Descrizione, Data, MatricolaAutore, IDAttivita) VALUES (?, ?, ?, ?)";
        String notifiche = "WITH destinatari AS ("
                + "SELECT pa.Matricola FROM Partecipa pa JOIN Attivita ax ON ax.IDProg = pa.IDProg WHERE ax.IDAttivita = ? "
                + "UNION SELECT p.Matricola_Dirigente FROM Progetto p JOIN Attivita ax ON ax.IDProg = p.IDProg WHERE ax.IDAttivita = ?) "
                + "INSERT INTO Notifica (messaggio, data_ora, letta, matricola_destinatario) "
                + "SELECT 'Nuovo commento di ' || u.Nome || ' ' || u.Cognome || ' nel progetto "
                + "' || p.Nome || ', attività ' || a.Nome || ': ' || CAST(? AS TEXT), CURRENT_TIMESTAMP, FALSE, d.Matricola "
                + "FROM Attivita a JOIN Progetto p ON p.IDProg = a.IDProg "
                + "JOIN Utente u ON u.Matricola = ? CROSS JOIN destinatari d "
                + "WHERE a.IDAttivita = ? AND d.Matricola <> ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement blocco = conn.prepareStatement(verifica)) {
                blocco.setInt(1, commento.getIdAttivita());
                try (ResultSet rs = blocco.executeQuery()) {
                    if (!rs.next() || "Finito".equals(rs.getString(1))) {
                        conn.rollback();
                        return false;
                    }
                }
            }
            try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, commento.getTesto());
                ps.setDate(2, new java.sql.Date((commento.getDataOra() == null ? new java.util.Date() : commento.getDataOra()).getTime()));
                ps.setString(3, commento.getMatricolaAutore());
                ps.setInt(4, commento.getIdAttivita());
                if (ps.executeUpdate() == 0) {
                    conn.rollback();
                    return false;
                }
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) commento.setIdCommento(keys.getInt(1));
                }
                try (PreparedStatement creaNotifiche = conn.prepareStatement(notifiche)) {
                    creaNotifiche.setInt(1, commento.getIdAttivita());
                    creaNotifiche.setInt(2, commento.getIdAttivita());
                    creaNotifiche.setString(3, commento.getTesto());
                    creaNotifiche.setString(4, commento.getMatricolaAutore());
                    creaNotifiche.setInt(5, commento.getIdAttivita());
                    creaNotifiche.setString(6, commento.getMatricolaAutore());
                    creaNotifiche.executeUpdate();
                }
                conn.commit();
                return true;
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
