package UninaTaskBoard_DAO;

import UninaTaskBoard_DB.DataBaseConnection;
import UninaTaskBoard_Model.Invito;
import UninaTaskBoard_Model.Progetto;
import UninaTaskBoard_Model.PartecipanteProgetto;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class ProgettoDAO {

    public Progetto getProgettoById(int idProg) {
        String query = "SELECT * FROM PROGETTO WHERE IDProg = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, idProg);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToProgetto(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Progetto> getProgettiPerUtente(String matricola) {
        List<Progetto> lista = new ArrayList<>();
        String query = "SELECT * FROM PROGETTO WHERE Matricola_Dirigente = ? "
                     + "OR IDProg IN (SELECT IDProg FROM PARTECIPA WHERE Matricola = ?) "
                     + "ORDER BY DataInizio DESC";

        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, matricola);
            ps.setString(2, matricola);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapResultSetToProgetto(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Progetto> getProgettiCoordinati(String matricolaDirigente) {
        List<Progetto> lista = new ArrayList<>();
        String query = "SELECT * FROM PROGETTO WHERE Matricola_Dirigente = ? ORDER BY DataInizio DESC";

        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, matricolaDirigente);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapResultSetToProgetto(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean creaProgetto(Progetto p) {
        String query = "INSERT INTO PROGETTO (Nome, DataInizio, DataScadenza, TipoProgetto, Materia, Linguaggio, Matricola_Dirigente) "
                     + "VALUES (?, ?, ?, ?::TipoProgettoEnum, ?, ?, ?)";

        try (Connection conn = DataBaseConnection.getInstance().getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, p.getNome());
                if (p.getDataInizio() != null) ps.setDate(2, new Date(p.getDataInizio().getTime()));
                else ps.setNull(2, Types.DATE);
                if (p.getDataScadenza() != null) ps.setDate(3, new Date(p.getDataScadenza().getTime()));
                else ps.setNull(3, Types.DATE);
                ps.setString(4, p.getTipoProgetto());
                ps.setString(5, p.getMateria());
                ps.setString(6, p.getLinguaggio());
                ps.setString(7, p.getMatricolaDirigente());
                if (ps.executeUpdate() == 0) {
                    conn.rollback();
                    return false;
                }
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (!generatedKeys.next()) {
                        conn.rollback();
                        return false;
                    }
                    p.setIdProg(generatedKeys.getInt(1));
                }
                try (PreparedStatement partecipa = conn.prepareStatement(
                        "INSERT INTO Partecipa (Matricola, IDProg, InizioPartecipazione) VALUES (?, ?, ?)")) {
                    partecipa.setString(1, p.getMatricolaDirigente());
                    partecipa.setInt(2, p.getIdProg());
                    partecipa.setDate(3, new Date(p.getDataInizio().getTime()));
                    partecipa.executeUpdate();
                }
                conn.commit();
                return true;
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean aggiornaProgetto(Progetto p) {
        String query = "UPDATE PROGETTO SET Nome = ?, DataInizio = ?, DataScadenza = ?, "
                     + "TipoProgetto = ?::TipoProgettoEnum, Materia = ?, Linguaggio = ?, Matricola_Dirigente = ? "
                     + "WHERE IDProg = ?";

        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, p.getNome());

            if (p.getDataInizio() != null) {
                ps.setDate(2, new Date(p.getDataInizio().getTime()));
            } else {
                ps.setNull(2, Types.DATE);
            }

            if (p.getDataScadenza() != null) {
                ps.setDate(3, new Date(p.getDataScadenza().getTime()));
            } else {
                ps.setNull(3, Types.DATE);
            }

            ps.setString(4, p.getTipoProgetto());
            ps.setString(5, p.getMateria());
            ps.setString(6, p.getLinguaggio());
            ps.setString(7, p.getMatricolaDirigente());
            ps.setInt(8, p.getIdProg());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean rinominaProgetto(int idProg, String matricolaDirigente, String nuovoNome) {
        String query = "UPDATE PROGETTO SET Nome = ? WHERE IDProg = ? AND Matricola_Dirigente = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, nuovoNome);
            ps.setInt(2, idProg);
            ps.setString(3, matricolaDirigente);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminaProgetto(int idProg) {
        String query = "DELETE FROM PROGETTO WHERE IDProg = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, idProg);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean aggiungiPartecipante(int idProg, String matricola) {
        String query = "INSERT INTO PARTECIPA (Matricola, IDProg, InizioPartecipazione) "
                + "SELECT ?, p.IDProg, GREATEST(CURRENT_DATE, p.DataInizio) FROM PROGETTO p WHERE p.IDProg = ? "
                + "AND (p.DataScadenza IS NULL OR GREATEST(CURRENT_DATE, p.DataInizio) <= p.DataScadenza) "
                + "ON CONFLICT (Matricola, IDProg) DO NOTHING";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, matricola);
            ps.setInt(2, idProg);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean invitaPartecipante(int idProg, String matricolaInvitante, String matricolaInvitata) {
        Invito invito = new Invito(0, matricolaInvitante, matricolaInvitata, idProg, "In Attesa", null);
        return new InvitoDAO().inviaInvito(invito);
    }

    public boolean rimuoviPartecipante(int idProg, String matricola) {
        String query = "DELETE FROM PARTECIPA WHERE IDProg = ? AND Matricola = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, idProg);
            ps.setString(2, matricola);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String> getMatricolePartecipanti(int idProg) {
        List<String> lista = new ArrayList<>();
        String query = "SELECT Matricola FROM PARTECIPA WHERE IDProg = ?";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, idProg);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(rs.getString("Matricola"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<PartecipanteProgetto> getPartecipantiProgetto(int idProg) {
        List<PartecipanteProgetto> lista = new ArrayList<>();
        String query = "SELECT u.Nome, u.Cognome, u.Matricola, "
                + "COALESCE(pa.InizioPartecipazione, p.DataInizio) AS DataPartecipazione, "
                + "(u.Matricola = p.Matricola_Dirigente) AS Dirigente "
                + "FROM Progetto p JOIN Utente u ON (u.Matricola = p.Matricola_Dirigente "
                + "OR EXISTS (SELECT 1 FROM Partecipa px WHERE px.IDProg = p.IDProg AND px.Matricola = u.Matricola)) "
                + "LEFT JOIN Partecipa pa ON pa.IDProg = p.IDProg AND pa.Matricola = u.Matricola "
                + "WHERE p.IDProg = ? ORDER BY u.Cognome, u.Nome";
        try (Connection conn = DataBaseConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, idProg);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new PartecipanteProgetto(rs.getString("Nome"), rs.getString("Cognome"),
                            rs.getString("Matricola"), rs.getDate("DataPartecipazione"), rs.getBoolean("Dirigente")));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    private Progetto mapResultSetToProgetto(ResultSet rs) throws SQLException {
        return new Progetto(
            rs.getInt("IDProg"),
            rs.getString("Nome"),
            rs.getDate("DataInizio"),
            rs.getDate("DataScadenza"),
            rs.getString("TipoProgetto"),
            rs.getString("Materia"),
            rs.getString("Linguaggio"),
            rs.getString("Matricola_Dirigente")
        );
    }
}
