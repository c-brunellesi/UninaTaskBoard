package UninaTaskBoard_DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnection {

    private static DataBaseConnection instance;
    private static final String URL = "jdbc:postgresql://localhost:5432/UninaTaskBoard";
    private static final String USER = "postgres";

    private DataBaseConnection() {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static synchronized DataBaseConnection getInstance() {
        if (instance == null) {
            instance = new DataBaseConnection();
        }
        return instance;
    }

    public Connection getConnection() throws SQLException {
        String password = System.getenv("DB_PASSWORD");
        if (password == null || password.isBlank()) {
            throw new SQLException("Variabile d'ambiente DB_PASSWORD non configurata.");
        }
        return DriverManager.getConnection(URL, USER, password);
    }
}
