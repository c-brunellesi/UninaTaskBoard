package UninaTaskBoard_Launcher;

import UninaTaskBoard_GUI.LoginFrame;

import javax.swing.SwingUtilities;
import java.awt.Taskbar;
import java.awt.Image;

public class MainUTB {
    public static void main(String[] args) {
        System.setProperty("apple.awt.application.name", "UninaTaskBoard");
        System.setProperty("com.apple.mrj.application.apple.menu.about.name", "UninaTaskBoard");
        SwingUtilities.invokeLater(() -> {
            LoginFrame login = new LoginFrame();
            login.setVisible(true);
            impostaIconaDock();
            login.toFront();
            login.requestFocus();
        });
    }

    private static void impostaIconaDock() {
        if (!Taskbar.isTaskbarSupported()) {
            return;
        }
        try {
            Taskbar taskbar = Taskbar.getTaskbar();
            if (taskbar.isSupported(Taskbar.Feature.ICON_IMAGE)) {
                Image icona = LoginFrame.caricaLogoDockIcona(1024);
                if (icona != null) {
                    taskbar.setIconImage(icona);
                }
            }
        } catch (UnsupportedOperationException | SecurityException ignored) {
        }
    }
}
