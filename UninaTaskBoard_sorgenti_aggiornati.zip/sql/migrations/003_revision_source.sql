ALTER TABLE Revisione
    ADD COLUMN IF NOT EXISTS CodiceSorgente TEXT;

UPDATE Revisione
SET CodiceSorgente = DescrizioneIntervento
WHERE CodiceSorgente IS NULL
  AND DescrizioneIntervento IS NOT NULL;
