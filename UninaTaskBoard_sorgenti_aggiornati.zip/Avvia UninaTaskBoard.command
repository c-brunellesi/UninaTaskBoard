#!/bin/bash
cd "$(dirname "$0")" || exit 1

if ! command -v java >/dev/null 2>&1 || ! command -v javac >/dev/null 2>&1; then
  printf 'Java 21 non risulta installato o configurato.\n'
  read -r -p 'Premi Invio per chiudere.'
  exit 1
fi

java_version=$(java -version 2>&1 | head -n 1)
if [[ "$java_version" != *'21.'* ]]; then
  printf 'Questa applicazione richiede Java 21. Versione rilevata: %s\n' "$java_version"
  read -r -p 'Premi Invio per chiudere.'
  exit 1
fi

if [[ ! -f lib/postgresql-42.7.13.jar || ! -f lib/jfreechart-1.5.5.jar ]]; then
  printf 'Non trovo le librerie necessarie nella cartella lib.\n'
  read -r -p 'Premi Invio per chiudere.'
  exit 1
fi

mkdir -p build
sources_file=$(mktemp)
find src -name '*.java' -print > "$sources_file"
if ! javac -cp 'lib/*' -d build @"$sources_file"; then
  rm -f "$sources_file"
  read -r -p 'Compilazione non riuscita. Premi Invio per chiudere.'
  exit 1
fi
rm -f "$sources_file"

printf 'Password PostgreSQL per l’utente postgres (non verrà salvata): '
IFS= read -r -s DB_PASSWORD
printf '\n'
if [[ -z "$DB_PASSWORD" ]]; then
  printf 'Password non inserita.\n'
  read -r -p 'Premi Invio per chiudere.'
  exit 1
fi
export DB_PASSWORD
java -cp 'build:src:lib/*' UninaTaskBoard_Launcher.MainUTB
result=$?
unset DB_PASSWORD
if [[ "$result" -ne 0 ]]; then
  printf '\nL’applicazione si è chiusa con un errore. Verifica che PostgreSQL sia avviato e che il database UninaTaskBoard sia disponibile.\n'
  read -r -p 'Premi Invio per chiudere.'
fi
exit "$result"
